﻿﻿# run.ps1 - Портативный спасатель Xiaomi Mi 9T (davinci)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "СПАСАТЕЛЬ XIAOMI MI 9T - prosh1vka"

$dir = $PSScriptRoot
$adb = Join-Path $dir "adb.exe"
$scrcpy = Join-Path $dir "scrcpy.exe"

$pubKey = "$env:USERPROFILE\.android\adbkey.pub"

Clear-Host
Write-Host "===============================================================" -ForegroundColor Red
Write-Host "             СПАСАТЕЛЬ XIAOMI MI 9T (davinci)                 " -ForegroundColor Yellow
Write-Host "       Автоматический взлом ADB-ключей и вывод экрана         " -ForegroundColor Cyan
Write-Host "===============================================================" -ForegroundColor Red
Write-Host ""

if (-not (Test-Path $pubKey)) {
    Write-Host "[!] Создаем новую пару ADB ключей на этом ПК..." -ForegroundColor Yellow
    & $adb keygen "$env:USERPROFILE\.android\adbkey"
}
Write-Host "[OK] ADB-ключ на этом ПК готов: $pubKey" -ForegroundColor Green
Write-Host ""
Write-Host "Ожидаю подключение телефона по USB кабелю..." -ForegroundColor Gray
Write-Host "(Если штекер разболтан - положи телефон неподвижно на стол)" -ForegroundColor DarkGray
Write-Host ""

while ($true) {
    $devicesOutput = & $adb devices 2>$null
    
    # 1. ТЕЛЕФОН В TWRP RECOVERY
    if ($devicesOutput -match '(\S+)\s+recovery') {
        $devId = $matches[1]
        Write-Host ""
        Write-Host ">>> [TWRP ОБНАРУЖЕН!] Устройство: $devId <<<" -ForegroundColor Green
        try { [Console]::Beep(1000, 200) } catch {}
        
        Write-Host "[1/4] Монтируем системные разделы прошивки..." -ForegroundColor Cyan
        & $adb shell "mount -t vfat /dev/block/bootdevice/by-name/modem /firmware 2>/dev/null; twrp mount /firmware 2>/dev/null"
        & $adb shell "mount -t ext4 /dev/block/bootdevice/by-name/vendor /vendor 2>/dev/null; twrp mount /vendor 2>/dev/null"
        
        Write-Host "[2/4] Проверяем диск /data..." -ForegroundColor Cyan
        & $adb shell "mount -t f2fs /dev/block/bootdevice/by-name/userdata /data 2>/dev/null; twrp mount data 2>/dev/null"
        
        $checkData = & $adb shell "ls -d /data/misc 2>/dev/null"
        if (-not ($checkData -match "/data/misc")) {
            Write-Host "[!] Диск зашифрован. Пробуем ввести известные PIN-коды..." -ForegroundColor Yellow
            & $adb shell "twrp decrypt 568920 0 2>/dev/null; twrp decrypt 568920 2>/dev/null"
            $checkData = & $adb shell "ls -d /data/misc 2>/dev/null"
            
            if (-not ($checkData -match "/data/misc")) {
                & $adb shell "twrp decrypt 56892 0 2>/dev/null; twrp decrypt 56892 2>/dev/null"
                $checkData = & $adb shell "ls -d /data/misc 2>/dev/null"
            }
        }
        
        if ($checkData -match "/data/misc") {
            Write-Host "[OK] Раздел /data успешно смонтирован и расшифрован!" -ForegroundColor Green
            
            Write-Host "[3/4] Зашиваем ADB-ключи ПК в телефон..." -ForegroundColor Cyan
            & $adb shell "mkdir -p /data/misc/adb /data/system"
            & $adb push $pubKey /data/misc/adb/adb_keys
            & $adb push $pubKey /data/system/adb_keys
            & $adb shell "chmod 640 /data/misc/adb/adb_keys /data/system/adb_keys"
            & $adb shell "chown 1000:1000 /data/misc/adb/adb_keys 2>/dev/null; chown system:shell /data/misc/adb/adb_keys 2>/dev/null"
            & $adb shell "chown 1000:1000 /data/system/adb_keys 2>/dev/null; chown system:shell /data/system/adb_keys 2>/dev/null"
            
            Write-Host "[OK] Ключи успешно внедрены в систему Android!" -ForegroundColor Green
            
            # Предложение бэкапа
            Write-Host ""
            Write-Host "--------------------------------------------------------" -ForegroundColor Yellow
            $backupChoice = Read-Host "Хочешь прямо сейчас скопировать фотки и данные на ПК? (Y/N)"
            if ($backupChoice -match "y|д") {
                $backupDir = Join-Path $dir "Mi9T_Backup"
                New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
                Write-Host "Копируем файлы в $backupDir..." -ForegroundColor Cyan
                & $adb pull "/data/media/0/DCIM" "$backupDir\DCIM"
                & $adb pull "/data/media/0/Download" "$backupDir\Download"
                & $adb pull "/data/media/0/Telegram" "$backupDir\Telegram"
                Write-Host "[OK] Бэкап завершен в $backupDir!" -ForegroundColor Green
            }
            
            Write-Host "[4/4] Перезагружаем телефон в обычную систему..." -ForegroundColor Cyan
            & $adb reboot
            Write-Host "Телефон перезагружается. Ждем загрузки системы для вывода экрана через scrcpy..." -ForegroundColor Yellow
            Start-Sleep -Seconds 12
        } else {
            Write-Host "[-] Не удалось расшифровать /data автоматически." -ForegroundColor Red
            Write-Host "Введите PIN-код или пароль вручную (или нажмите Enter для пропуска):" -ForegroundColor Yellow
            $userPin = Read-Host "PIN"
            if ($userPin) {
                & $adb shell "twrp decrypt $userPin 0 2>/dev/null; twrp decrypt $userPin 2>/dev/null"
            }
        }
    }
    # 2. ТЕЛЕФОН В СИСТЕМЕ И АВТОРИЗОВАН!
    elseif ($devicesOutput -match '(\S+)\s+device') {
        $devId = $matches[1]
        Write-Host ""
        Write-Host ">>> [ТЕЛЕФОН В СИСТЕМЕ И АВТОРИЗОВАН!] ID: $devId <<<" -ForegroundColor Green
        try { [Console]::Beep(1200, 300) } catch {}
        Write-Host "Запускаю вывод экрана через SCRCPY на монитор..." -ForegroundColor Cyan
        Write-Host "(Управляй телефоном мышкой и клавиатурой прямо в открывшемся окне!)" -ForegroundColor Yellow
        Write-Host ""
        
        $scrcpyArgs = @("--stay-awake", "--window-title", "Xiaomi Mi 9T Screen Mirror")
        Start-Process -FilePath $scrcpy -ArgumentList $scrcpyArgs
        
        Write-Host "Окно scrcpy запущено!" -ForegroundColor Green
        Write-Host "Нажми любую клавишу для выхода..." -ForegroundColor Gray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        break
    }
    # 3. ТЕЛЕФОН В СИСТЕМЕ, НО КЛЮЧ НЕ ПРОПИСАН
    elseif ($devicesOutput -match '(\S+)\s+unauthorized') {
        Write-Host "`r[!] Телефон в Android, но отладка UNAUTHORIZED. Зажми Громкость ВВЕРХ + Питание для входа в TWRP!  " -ForegroundColor Yellow -NoNewline
    }
    else {
        Write-Host "`r[?] Телефон не найден... Проверь кабель Type-C.                                                       " -ForegroundColor DarkGray -NoNewline
    }
    
    Start-Sleep -Milliseconds 600
}
