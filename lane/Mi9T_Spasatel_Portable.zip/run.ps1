﻿﻿﻿# run.ps1 - Портативный спасатель Xiaomi Mi 9T (davinci)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "СПАСАТЕЛЬ XIAOMI MI 9T - prosh1vka"

$dir = $PSScriptRoot
$adb = Join-Path $dir "adb.exe"
$scrcpy = Join-Path $dir "scrcpy.exe"
$pubKey = "$env:USERPROFILE\.android\adbkey.pub"

Clear-Host
Write-Host "===============================================================" -ForegroundColor Red
Write-Host "             СПАСАТЕЛЬ XIAOMI MI 9T (davinci)                 " -ForegroundColor Yellow
Write-Host "       Автоматический взлом ADB-ключей и вывод экрана         " -ForegroundColor Cyan
Write-Host "===============================================================" -ForegroundColor Red
Write-Host ""

# Проверяем или генерируем ADB-ключ на этом ПК
if (-not (Test-Path $pubKey)) {
    Write-Host "[!] Создаем новую пару ADB ключей на этом ПК..." -ForegroundColor Yellow
    $androidDir = "$env:USERPROFILE\.android"
    if (-not (Test-Path $androidDir)) { New-Item -ItemType Directory -Path $androidDir -Force | Out-Null }
    & $adb keygen "$env:USERPROFILE\.android\adbkey"
}
Write-Host "[OK] ADB-ключ на этом ПК готов: $pubKey" -ForegroundColor Green
Write-Host ""
Write-Host "Ожидаю подключение телефона по USB кабелю..." -ForegroundColor Gray
Write-Host "(Если штекер разболтан - положи телефон неподвижно на стол)" -ForegroundColor DarkGray
Write-Host ""

function Check-DataMounted {
    $out = & $adb shell "ls -d /data/misc /data/system /data/media 2>/dev/null"
    if ($out -match "/data/misc|/data/system|/data/media") {
        return $true
    }
    return $false
}

function Try-TwrpDecrypt {
    param([string]$Pin)
    $Pin = $Pin.Trim()
    if (-not $Pin) { return $false }
    Write-Host "[*] Пробуем расшифровать TWRP с PIN: '$Pin'..." -ForegroundColor Cyan
    
    # 1. Попытка стандартного decrypt
    $res1 = & $adb shell "twrp decrypt $Pin 2>&1"
    if ($res1) { Write-Host "    TWRP: $res1" -ForegroundColor Gray }
    
    & $adb shell "twrp mount /data 2>&1" | Out-Null
    if (Check-DataMounted) { return $true }
    
    # 2. Попытка с указанием пользователя 0 (FBE multi-user)
    $res2 = & $adb shell "twrp decrypt $Pin 0 2>&1"
    if ($res2) { Write-Host "    TWRP (u0): $res2" -ForegroundColor Gray }
    
    & $adb shell "twrp mount /data 2>&1" | Out-Null
    if (Check-DataMounted) { return $true }
    
    return $false
}

while ($true) {
    $devicesOutput = & $adb devices 2>$null
    
    # =========================================================================
    # 1. ТЕЛЕФОН В TWRP RECOVERY
    # =========================================================================
    if ($devicesOutput -match '(\S+)\s+recovery') {
        $devId = $matches[1]
        Write-Host ""
        Write-Host "===============================================================" -ForegroundColor Green
        Write-Host ">>> [TWRP ОБНАРУЖЕН!] Устройство: $devId <<<" -ForegroundColor Green
        Write-Host "===============================================================" -ForegroundColor Green
        try { [Console]::Beep(1000, 200) } catch {}
        
        Write-Host "[1/4] Монтируем системные разделы и прошивку..." -ForegroundColor Cyan
        & $adb shell "twrp mount /firmware" | Out-Null
        & $adb shell "twrp mount /vendor" | Out-Null
        & $adb shell "twrp mount /system" | Out-Null
        & $adb shell "twrp mount /data" | Out-Null
        
        $dataReady = Check-DataMounted
        
        # Если диск зашифрован - пробуем известные PIN
        if (-not $dataReady) {
            Write-Host "[2/4] Диск зашифрован. Пробуем сохраненные PIN-коды..." -ForegroundColor Yellow
            
            $knownPins = @("568920", "56892")
            foreach ($p in $knownPins) {
                if (Try-TwrpDecrypt -Pin $p) {
                    $dataReady = $true
                    Write-Host "[OK] Успешно расшифровано по коду $p!" -ForegroundColor Green
                    break
                }
            }
        }
        
        # Если всё ещё не расшифрован - запрашиваем у пользователя в цикле
        while (-not $dataReady) {
            Write-Host ""
            Write-Host "[-] Раздел /data пока не расшифрован." -ForegroundColor Red
            Write-Host "Последние логи TWRP:" -ForegroundColor DarkGray
            & $adb shell "tail -n 8 /tmp/recovery.log 2>/dev/null"
            Write-Host ""
            Write-Host "Введи PIN-код экрана телефона (или нажми Enter для повторной попытки 568920):" -ForegroundColor Yellow
            $inputPin = Read-Host "PIN"
            if (-not $inputPin) { $inputPin = "568920" }
            
            if (Try-TwrpDecrypt -Pin $inputPin) {
                $dataReady = $true
                Write-Host "[OK] Успешно расшифровано с кодом $inputPin!" -ForegroundColor Green
                break
            } else {
                Write-Host "[X] Код $inputPin не подошел или TWRP выдал ошибку." -ForegroundColor Red
                Write-Host "Хочешь попробовать снова? (Y/N)" -ForegroundColor Gray
                $retry = Read-Host
                if ($retry -match "n|н") { break }
            }
        }
        
        # ЕСЛИ /DATA РАСШИФРОВАН И ДОСТУПЕН - ЗАШИВАЕМ КЛЮЧИ!
        if ($dataReady) {
            Write-Host ""
            Write-Host "[3/4] Раздел /data готов! Внедряем ADB-ключи ПК в телефон..." -ForegroundColor Cyan
            
            & $adb shell "mkdir -p /data/misc/adb"
            & $adb shell "mkdir -p /data/system"
            
            Write-Host "Копируем ключ в /data/misc/adb/adb_keys..." -ForegroundColor Gray
            & $adb push $pubKey /data/misc/adb/adb_keys
            
            Write-Host "Копируем ключ в /data/system/adb_keys..." -ForegroundColor Gray
            & $adb push $pubKey /data/system/adb_keys
            
            # Выставляем права 640 и владельца system / shell
            & $adb shell "chmod 640 /data/misc/adb/adb_keys /data/system/adb_keys"
            & $adb shell "chown 1000:1000 /data/misc/adb/adb_keys /data/system/adb_keys 2>/dev/null"
            & $adb shell "chown system:shell /data/misc/adb/adb_keys /data/system/adb_keys 2>/dev/null"
            
            # Проверяем наличие ключа
            $verifyKeys = & $adb shell "ls -la /data/misc/adb/adb_keys 2>/dev/null"
            Write-Host "[OK] Статус ключа: $verifyKeys" -ForegroundColor Green
            Write-Host "[OK] КЛЮЧИ УСПЕШНО ЗАШИТЫ В ТЕЛЕФОН!" -ForegroundColor Green
            
            # Предложение бэкапа
            Write-Host ""
            Write-Host "--------------------------------------------------------" -ForegroundColor Yellow
            $backupChoice = Read-Host "Хочешь прямо сейчас скопировать фотки и файлы на ПК? (Y/N)"
            if ($backupChoice -match "y|д") {
                $backupDir = Join-Path $dir "Mi9T_Backup"
                New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
                Write-Host "Копируем файлы в $backupDir..." -ForegroundColor Cyan
                & $adb pull "/data/media/0/DCIM" "$backupDir\DCIM"
                & $adb pull "/data/media/0/Download" "$backupDir\Download"
                & $adb pull "/data/media/0/Telegram" "$backupDir\Telegram"
                Write-Host "[OK] Бэкап завершен в $backupDir!" -ForegroundColor Green
            }
            
            Write-Host ""
            Write-Host "[4/4] Перезагружаем телефон в обычную систему..." -ForegroundColor Cyan
            & $adb reboot
            Write-Host "Телефон перезагружается в систему Android." -ForegroundColor Yellow
            Write-Host "Ждем загрузки системы (около 20-30 сек) для автоматического открытия экрана..." -ForegroundColor Yellow
            Start-Sleep -Seconds 15
        } else {
            Write-Host "[!] Пропуск шага заливки ключей (диск не расшифрован)." -ForegroundColor Yellow
            Start-Sleep -Seconds 3
        }
    }
    # =========================================================================
    # 2. ТЕЛЕФОН В СИСТЕМЕ И АВТОРИЗОВАН!
    # =========================================================================
    elseif ($devicesOutput -match '(\S+)\s+device') {
        $devId = $matches[1]
        Write-Host ""
        Write-Host "===============================================================" -ForegroundColor Green
        Write-Host ">>> [ТЕЛЕФОН В СИСТЕМЕ И АВТОРИЗОВАН!] ID: $devId <<<" -ForegroundColor Green
        Write-Host "===============================================================" -ForegroundColor Green
        try { [Console]::Beep(1200, 300) } catch {}
        Write-Host "Запускаю вывод экрана через SCRCPY на монитор..." -ForegroundColor Cyan
        Write-Host "(Управляй телефоном мышкой и клавиатурой прямо в открывшемся окне!)" -ForegroundColor Yellow
        Write-Host ""
        
        $scrcpyArgs = @("--stay-awake", "--window-title", "Xiaomi Mi 9T Screen Mirror")
        Start-Process -FilePath $scrcpy -ArgumentList $scrcpyArgs
        
        Write-Host "[OK] Окно scrcpy запущено!" -ForegroundColor Green
        Write-Host "Нажми любую клавишу для выхода..." -ForegroundColor Gray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        break
    }
    # =========================================================================
    # 3. ТЕЛЕФОН В СИСТЕМЕ, НО КЛЮЧ НЕ ПРОПИСАН
    # =========================================================================
    elseif ($devicesOutput -match '(\S+)\s+unauthorized') {
        Write-Host "`r[!] Телефон в Android, но отладка UNAUTHORIZED. Зажми Громкость ВВЕРХ + Питание для входа в TWRP!  " -ForegroundColor Yellow -NoNewline
    }
    else {
        Write-Host "`r[?] Телефон не найден... Проверь кабель Type-C.                                                       " -ForegroundColor DarkGray -NoNewline
    }
    
    Start-Sleep -Milliseconds 600
}
