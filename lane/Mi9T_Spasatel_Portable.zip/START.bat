@echo off
chcp 65001 >nul
title СПАСАТЕЛЬ XIAOMI MI 9T
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
pause
