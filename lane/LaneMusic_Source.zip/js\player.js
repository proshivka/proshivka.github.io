// player.js - Audio Player, SMTC and Equalizer for Lumia 650
(function(window) {
    'use strict';

    var audio = null;
    var smtc = null;
    var queue = [];
    var currentIndex = -1;
    var isPlaying = false;
    var currentSessionId = 0;
    var repeatMode = 'off'; // 'off' | 'all' | 'one'
    var userInitiatedPause = false;

    // Preloading for Seamless Lockscreen Autoplay
    var preloadedNextTrackId = null;
    var preloadedNextStreamUrl = null;
    var extendedSession = null;

    function ensureExtendedExecution() {
        try {
            if (extendedSession) return;
            if (typeof Windows !== 'undefined' && Windows.ApplicationModel && Windows.ApplicationModel.ExtendedExecution) {
                var session = new Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionSession();
                session.reason = Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionReason.unspecified;
                session.description = "LANE Music Continuous Background Audio";
                session.addEventListener('revoked', function() {
                    extendedSession = null;
                });
                session.requestExtensionAsync().then(function(res) {
                    if (res === Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult.allowed) {
                        extendedSession = session;
                    }
                });
            }
        } catch(e) {}
    }

    function clearExtendedExecution() {
        try {
            if (extendedSession) {
                extendedSession.close();
                extendedSession = null;
            }
        } catch(e) {}
    }

    function prefetchNextTrack() {
        if (!queue || queue.length <= 1) return;
        var nextIdx = (currentIndex < queue.length - 1) ? currentIndex + 1 : (repeatMode === 'all' ? 0 : -1);
        if (nextIdx === -1) return;
        var nextTrack = queue[nextIdx];
        if (!nextTrack || !nextTrack.id) return;

        var cached = LaneApi.getCachedStreamUrl(nextTrack.id);
        if (cached) {
            preloadedNextTrackId = nextTrack.id;
            preloadedNextStreamUrl = cached;
            return;
        }

        if (preloadedNextTrackId === nextTrack.id && preloadedNextStreamUrl) return;

        LaneApi.getStreamUrl(nextTrack.id, nextTrack.platform).then(function(res) {
            var sUrl = '';
            if (typeof res === 'string') sUrl = res;
            else if (res && res.url) sUrl = res.url;
            else if (res && res.streamUrl) sUrl = res.streamUrl;
            else if (res && res.data && res.data.url) sUrl = res.data.url;

            if (sUrl) {
                preloadedNextTrackId = nextTrack.id;
                preloadedNextStreamUrl = sUrl;
                LaneApi.cacheStreamUrl(nextTrack.id, sUrl);
                console.log('Prefetched next track for instant transition:', nextTrack.title);
            }
        }).catch(function(err) {
            console.warn('Prefetch error:', err);
        });
    }

    // Web Audio Equalizer nodes
    var audioCtx = null;
    var audioSourceNode = null;
    var bassFilter = null;
    var eqFilters = [];
    var isEqConnected = false;

    function initAudioContext() {
        if (isEqConnected) {
            if (audioCtx && audioCtx.state === 'suspended') {
                try { audioCtx.resume(); } catch(e) {}
            }
            return;
        }
        try {
            var AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass || !audio) return;

            if (!audioCtx) {
                audioCtx = new AudioContextClass();
            }
            if (audioCtx.state === 'suspended') {
                try { audioCtx.resume(); } catch(e) {}
            }

            if (!audioSourceNode) {
                audioSourceNode = audioCtx.createMediaElementSource(audio);
            }

            if (!bassFilter) {
                bassFilter = audioCtx.createBiquadFilter();
                bassFilter.type = 'lowshelf';
                bassFilter.frequency.value = 80;
                var bassOn = (localStorage.getItem('lane_bass_boost') === '1');
                bassFilter.gain.value = bassOn ? 14 : 0;
            }

            if (eqFilters.length === 0) {
                var f60 = audioCtx.createBiquadFilter();
                f60.type = 'lowshelf';
                f60.frequency.value = 60;
                f60.gain.value = 0;

                var f250 = audioCtx.createBiquadFilter();
                f250.type = 'peaking';
                f250.frequency.value = 250;
                f250.gain.value = 0;

                var f1k = audioCtx.createBiquadFilter();
                f1k.type = 'peaking';
                f1k.frequency.value = 1000;
                f1k.gain.value = 0;

                var f4k = audioCtx.createBiquadFilter();
                f4k.type = 'highshelf';
                f4k.frequency.value = 4000;
                f4k.gain.value = 0;

                eqFilters = [f60, f250, f1k, f4k];

                audioSourceNode.connect(bassFilter);
                bassFilter.connect(f60);
                f60.connect(f250);
                f250.connect(f1k);
                f1k.connect(f4k);
                f4k.connect(audioCtx.destination);
            }

            // Restore saved preset
            var savedPreset = localStorage.getItem('lane_eq_preset') || 'normal';
            Player.applyPreset(savedPreset);

            isEqConnected = true;
            console.log('Web Audio Equalizer successfully connected and active!');
        } catch(e) {
            console.warn('initAudioContext error:', e);
        }
    }

    var Player = {
        currentTrack: null,
        repeatMode: 'off',

        init: function() {
            audio = document.getElementById('audioPlayer') || new Audio();
            audio.id = 'audioPlayer';
            audio.preload = 'auto';

            try {
                audio.msAudioCategory = 'BackgroundCapableMedia';
                audio.setAttribute('msAudioCategory', 'BackgroundCapableMedia');
            } catch(e) {}

            var self = this;

            audio.addEventListener('play', function() {
                userInitiatedPause = false;
                isPlaying = true;
                self.updateUI(false);
                self.updateSmtcStatus();
                ensureExtendedExecution();
                if (audioCtx && audioCtx.state === 'suspended') {
                    try { audioCtx.resume(); } catch(e) {}
                }
            });

            audio.addEventListener('playing', function() {
                userInitiatedPause = false;
                isPlaying = true;
                self.updateUI(false);
                self.updateSmtcStatus();
                ensureExtendedExecution();
            });

            audio.addEventListener('pause', function() {
                if (!userInitiatedPause && isPlaying) {
                    console.log('Detected OS screen lock pause, auto-resuming playback...');
                    setTimeout(function() {
                        if (audio.src && !userInitiatedPause) {
                            ensureExtendedExecution();
                            var p = audio.play();
                            if (p && typeof p.catch === 'function') {
                                p.catch(function(e) { console.warn('Auto-resume error:', e); });
                            }
                        }
                    }, 50);
                    return;
                }
                isPlaying = false;
                clearExtendedExecution();
                self.updateUI(false);
                self.updateSmtcStatus();
            });

            // Windows UWP App Lifecycle handling for continuous background playback
            try {
                if (typeof Windows !== 'undefined' && Windows.UI && Windows.UI.WebUI && Windows.UI.WebUI.WebUIApplication) {
                    Windows.UI.WebUI.WebUIApplication.addEventListener('suspending', function(e) {
                        if (isPlaying && !userInitiatedPause) {
                            var deferral = e.suspendingOperation.getDeferral();
                            setTimeout(function() {
                                try { deferral.complete(); } catch(ex) {}
                            }, 4000);
                        }
                    });
                    Windows.UI.WebUI.WebUIApplication.addEventListener('resuming', function() {
                        ensureExtendedExecution();
                        if (isPlaying && audio && audio.paused && !userInitiatedPause) {
                            try { audio.play(); } catch(ex) {}
                        }
                    });
                }
            } catch(e) {}

            document.addEventListener('visibilitychange', function() {
                if (!document.hidden && audioCtx && audioCtx.state === 'suspended') {
                    try { audioCtx.resume(); } catch(e) {}
                }
            });

            window.addEventListener('focus', function() {
                if (audioCtx && audioCtx.state === 'suspended') {
                    try { audioCtx.resume(); } catch(e) {}
                }
            });

            audio.addEventListener('timeupdate', function() {
                self.onTimeUpdate();
                // When 1.5 seconds passed, prefetch next track stream URL for instant transition
                if (audio.currentTime > 1.5 && !preloadedNextStreamUrl) {
                    prefetchNextTrack();
                }
            });

            audio.addEventListener('ended', function() {
                console.log('Track ended, handling auto-advance...');
                if (repeatMode === 'one') {
                    audio.currentTime = 0;
                    audio.play();
                    return;
                }
                self.next(true);
            });

            audio.addEventListener('error', function(e) {
                console.error('Audio playback error:', e);
                if (self.currentTrack) {
                    self.showNotification('Ошибка воспроизведения: ' + self.currentTrack.title);
                }
            });

            // Windows 10 Mobile System Media Transport Controls
            try {
                if (typeof Windows !== 'undefined' && Windows.Media && Windows.Media.SystemMediaTransportControls) {
                    smtc = Windows.Media.SystemMediaTransportControls.getForCurrentView();
                    if (smtc) {
                        smtc.isEnabled = true;
                        smtc.isPlayEnabled = true;
                        smtc.isPauseEnabled = true;
                        smtc.isNextEnabled = true;
                        smtc.isPreviousEnabled = true;

                        smtc.addEventListener('buttonpressed', function(e) {
                            try {
                                var btn = Windows.Media.SystemMediaTransportControlsButton;
                                switch (e.button) {
                                    case btn.play: self.play(); break;
                                    case btn.pause: self.pause(); break;
                                    case btn.next: self.next(); break;
                                    case btn.previous: self.prev(); break;
                                }
                            } catch(ex) {}
                        });
                        console.log('SMTC successfully initialized for Background Audio');
                    }
                }
            } catch (e) {
                console.warn('SMTC init warning:', e);
            }
        },

        initEqualizer: function() {
            initAudioContext();
        },

        playTrack: function(track, playlist, explicitIndex) {
            var self = this;
            var thisSessionId = ++currentSessionId;

            // Immediately abort any inflight stream request from previous track
            LaneApi.abortStreamRequest();

            if (playlist && Array.isArray(playlist)) {
                queue = playlist;
                if (typeof explicitIndex === 'number' && explicitIndex >= 0 && explicitIndex < playlist.length) {
                    currentIndex = explicitIndex;
                } else {
                    currentIndex = playlist.findIndex(function(t) { return t.id === track.id; });
                }
            } else if (queue.indexOf(track) === -1) {
                queue.push(track);
                currentIndex = queue.length - 1;
            }

            this.currentTrack = track;
            this.updateUI(true);
            this.updateSmtcMetadata(track);

            function startAudio(streamUrl) {
                if (thisSessionId !== currentSessionId) {
                    console.log('Discarding obsolete stream for track:', track.title);
                    return;
                }
                console.log('Playing:', track.title, '=>', streamUrl);
                try {
                    audio.msAudioCategory = 'BackgroundCapableMedia';
                    audio.setAttribute('msAudioCategory', 'BackgroundCapableMedia');
                } catch(e) {}
                userInitiatedPause = false;
                audio.src = streamUrl;
                var p = audio.play();
                if (p && typeof p.catch === 'function') {
                    p.catch(function(err) {
                        console.warn('Playback start error:', err);
                    });
                }
                ensureExtendedExecution();
                // Schedule prefetch for the next track in 1.5s
                setTimeout(function() {
                    prefetchNextTrack();
                }, 1500);
            }

            // 1. Check instant 0ms cached URL
            var cachedUrl = LaneApi.getCachedStreamUrl(track.id);
            if (cachedUrl) {
                console.log('Instant start from cache (0ms):', track.title);
                startAudio(cachedUrl);
                return;
            }

            // 2. Instant transition if preloaded for lockscreen
            if (preloadedNextTrackId === track.id && preloadedNextStreamUrl) {
                var preloaded = preloadedNextStreamUrl;
                preloadedNextTrackId = null;
                preloadedNextStreamUrl = null;
                startAudio(preloaded);
                return;
            }

            preloadedNextTrackId = null;
            preloadedNextStreamUrl = null;

            this.showNotification('Загрузка: ' + track.title);

            // Fetch stream URL with platform info
            LaneApi.getStreamUrl(track.id, track.platform).then(function(res) {
                if (thisSessionId !== currentSessionId) {
                    console.log('Session expired, ignoring stream response');
                    return;
                }

                var streamUrl = '';
                if (typeof res === 'string') {
                    streamUrl = res;
                } else if (res && res.url) {
                    streamUrl = res.url;
                } else if (res && res.streamUrl) {
                    streamUrl = res.streamUrl;
                } else if (res && res.data && res.data.url) {
                    streamUrl = res.data.url;
                }

                if (!streamUrl) {
                    self.showNotification('Поток недоступен: ' + track.title);
                    return;
                }

                startAudio(streamUrl);
            }).catch(function(err) {
                if (thisSessionId !== currentSessionId) return;
                if (err && err.aborted) {
                    console.log('Stream request aborted for new track');
                    return;
                }
                console.error('getStreamUrl failed:', err);
                if (err && err.status === 401) {
                    self.showNotification('Требуется вход в аккаунт LANE');
                } else {
                    self.showNotification('Поток недоступен (' + ((err && err.message) || 'ошибка') + ')');
                }
            });
        },

        togglePlay: function() {
            if (!this.currentTrack) return;
            if (audio.paused) {
                this.play();
            } else {
                this.pause();
            }
        },

        play: function() {
            userInitiatedPause = false;
            if (audio.src) {
                audio.play();
            }
        },

        pause: function() {
            userInitiatedPause = true;
            audio.pause();
        },

        next: function(isAutoAdvance) {
            if (queue.length === 0) return;
            if (currentIndex < queue.length - 1) {
                currentIndex++;
            } else {
                if (isAutoAdvance && repeatMode === 'off') {
                    console.log('End of queue reached with repeat off');
                    isPlaying = false;
                    this.updateUI(false);
                    this.updateSmtcStatus();
                    return;
                }
                currentIndex = 0;
            }
            this.playTrack(queue[currentIndex], queue, currentIndex);
        },

        prev: function() {
            if (queue.length === 0) return;
            if (audio.currentTime > 3) {
                audio.currentTime = 0;
                return;
            }
            if (currentIndex > 0) {
                currentIndex--;
            } else {
                currentIndex = queue.length - 1;
            }
            this.playTrack(queue[currentIndex], queue, currentIndex);
        },

        seek: function(percent) {
            if (audio.duration) {
                audio.currentTime = (percent / 100) * audio.duration;
            }
        },

        toggleRepeat: function() {
            if (repeatMode === 'off') {
                repeatMode = 'all';
            } else if (repeatMode === 'all') {
                repeatMode = 'one';
            } else {
                repeatMode = 'off';
            }
            this.repeatMode = repeatMode;
            if (audio) {
                audio.loop = (repeatMode === 'one');
            }
            this.updateRepeatUI();
            var msg = (repeatMode === 'one') ? 'Повтор: этот трек' : (repeatMode === 'all') ? 'Повтор: вся очередь' : 'Повтор: выключен';
            this.showNotification(msg);
            return repeatMode;
        },

        updateRepeatUI: function() {
            var btn = document.getElementById('fullRepeatBtn');
            if (!btn) return;
            var icon = btn.querySelector('.mdl2');
            if (repeatMode === 'one') {
                btn.classList.add('active');
                if (icon) icon.innerHTML = '&#xE8ED;';
                btn.style.opacity = '1';
                btn.style.color = '#e51c23';
            } else if (repeatMode === 'all') {
                btn.classList.add('active');
                if (icon) icon.innerHTML = '&#xE8EE;';
                btn.style.opacity = '1';
                btn.style.color = '#e51c23';
            } else {
                btn.classList.remove('active');
                if (icon) icon.innerHTML = '&#xE8EE;';
                btn.style.opacity = '0.5';
                btn.style.color = '#ffffff';
            }
        },

        // Equalizer Controls
        setBassBoost: function(enabled) {
            initAudioContext();
            try {
                if (bassFilter && bassFilter.gain) {
                    bassFilter.gain.value = enabled ? 14 : 0;
                }
                localStorage.setItem('lane_bass_boost', enabled ? '1' : '0');
            } catch(e) {}
        },

        setBandGain: function(bandIndex, gainVal) {
            initAudioContext();
            try {
                if (eqFilters && eqFilters[bandIndex] && eqFilters[bandIndex].gain) {
                    eqFilters[bandIndex].gain.value = parseFloat(gainVal) || 0;
                }
            } catch(e) {}
        },

        applyPreset: function(presetName) {
            initAudioContext();
            var presets = {
                'normal': [0, 0, 0, 0],
                'bass': [10, 6, 0, 2],
                'hardtekk': [14, 8, 2, 4],
                'vocal': [-2, 2, 6, 4],
                'electro': [8, 3, 2, 6]
            };
            var vals = presets[presetName] || presets.normal;
            try {
                for (var i = 0; i < eqFilters.length; i++) {
                    if (eqFilters[i] && eqFilters[i].gain) eqFilters[i].gain.value = vals[i];
                }
                var bassOn = (localStorage.getItem('lane_bass_boost') === '1');
                if (bassFilter && bassFilter.gain) {
                    bassFilter.gain.value = bassOn ? 14 : 0;
                }
                localStorage.setItem('lane_eq_preset', presetName);
            } catch(e) {}
            return vals;
        },

        updateSmtcStatus: function() {
            if (!smtc || typeof Windows === 'undefined') return;
            try {
                var status = Windows.Media.MediaPlaybackStatus;
                smtc.playbackStatus = isPlaying ? status.playing : status.paused;
            } catch (e) {}
        },

        updateSmtcMetadata: function(track) {
            if (!smtc || typeof Windows === 'undefined') return;
            try {
                var updater = smtc.displayUpdater;
                updater.type = Windows.Media.MediaPlaybackType.music;
                updater.musicProperties.title = track.title || 'LANE';
                updater.musicProperties.artist = track.artist || 'LANE';
                if (track.coverUrl && track.coverUrl.indexOf('http') === 0) {
                    try {
                        updater.thumbnail = Windows.Storage.Streams.RandomAccessStreamReference.createFromUri(new Windows.Foundation.Uri(track.coverUrl));
                    } catch(ex) {}
                }
                updater.update();
            } catch (e) {}
        },

        onTimeUpdate: function() {
            var cur = audio.currentTime || 0;
            var dur = audio.duration || 1;
            var pct = (cur / dur) * 100;

            var miniBar = document.getElementById('miniProgressBar');
            if (miniBar) miniBar.style.width = pct + '%';

            var fullBar = document.getElementById('fullProgressFill');
            if (fullBar) fullBar.style.width = pct + '%';

            var fullTime = document.getElementById('fullCurrentTime');
            if (fullTime) fullTime.innerText = this.formatTime(cur);

            var fullDuration = document.getElementById('fullDuration');
            if (fullDuration && audio.duration) fullDuration.innerText = this.formatTime(dur);
        },

        formatTime: function(sec) {
            if (!sec || isNaN(sec)) return '0:00';
            var m = Math.floor(sec / 60);
            var s = Math.floor(sec % 60);
            return m + ':' + (s < 10 ? '0' : '') + s;
        },

        updateUI: function(isLoading) {
            var track = this.currentTrack;
            if (!track) return;

            var miniPlayer = document.getElementById('miniPlayer');
            if (miniPlayer) miniPlayer.classList.add('visible');

            var miniTitle = document.getElementById('miniTitle');
            if (miniTitle) {
                miniTitle.innerText = isLoading ? ('[Загрузка] ' + (track.title || '')) : (track.title || 'Без названия');
            }

            var miniArtist = document.getElementById('miniArtist');
            if (miniArtist) miniArtist.innerText = track.artist || 'LANE';

            var miniCover = document.getElementById('miniCover');
            if (miniCover) {
                miniCover.onerror = function() { this.onerror = null; this.src = 'assets/default_cover.png'; };
                miniCover.src = track.coverUrl || 'assets/default_cover.png';
            }

            var miniIcon = document.getElementById('miniPlayIcon');
            if (miniIcon) miniIcon.innerHTML = isPlaying ? '&#xE769;' : '&#xE768;';

            var fullTitle = document.getElementById('fullTitle');
            if (fullTitle) {
                fullTitle.innerText = isLoading ? ('[Загрузка] ' + (track.title || '')) : (track.title || 'Без названия');
            }

            var fullArtist = document.getElementById('fullArtist');
            if (fullArtist) {
                var platBadge = '';
                var plat = (track.platform || '').toLowerCase();
                if (plat.indexOf('spotify') !== -1) {
                    platBadge = '<img src="assets/spotify_logo.png" class="metro-platform-badge" alt="Spotify"> ';
                } else if (plat.indexOf('soundcloud') !== -1 || plat === 'sc') {
                    platBadge = '<img src="assets/soundcloud_logo.png" class="metro-platform-badge" alt="SoundCloud"> ';
                }
                fullArtist.innerHTML = platBadge + escapeHtml(track.artist || 'LANE');
            }

            var fullCover = document.getElementById('fullCover');
            if (fullCover) {
                fullCover.onerror = function() { this.onerror = null; this.src = 'assets/default_cover.png'; };
                fullCover.src = track.coverUrl || 'assets/default_cover.png';
            }

            var fullIcon = document.getElementById('fullPlayIcon');
            if (fullIcon) fullIcon.innerHTML = isPlaying ? '&#xE769;' : '&#xE768;';

            this.updateRepeatUI();

            // Notify app about track change (e.g. for Like button state)
            if (typeof window.onPlayerTrackChanged === 'function') {
                window.onPlayerTrackChanged(track);
            }

            var allItems = document.querySelectorAll('.metro-track-item');
            for (var i = 0; i < allItems.length; i++) {
                var it = allItems[i];
                if (it.getAttribute('data-id') === track.id) {
                    it.classList.add('playing');
                    var durSpan = it.querySelector('.metro-duration');
                    if (durSpan && isLoading) {
                        durSpan.innerText = 'Загрузка...';
                    }
                } else {
                    it.classList.remove('playing');
                }
            }
        },

        showNotification: function(msg) {
            var toast = document.getElementById('toast');
            if (toast) {
                toast.innerText = msg;
                toast.classList.add('show');
                setTimeout(function() {
                    toast.classList.remove('show');
                }, 2800);
            }
        }
    };

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    window.Player = Player;
})(window);
