// lane-crypto.js - Cryptographic engine for Lane API
(function(window) {
    'use strict';

    var MASTER_KEY = 'SqperSzvbntKmv_CbnngeThis_12303!';
    var CUSTOM_B64_CHARS = 'zxcvbnmasdfghjklqwertyuiop1234567890-_QWERTYUIOPASDFGHJKLZXCVBNM';

    function sha256_bytes(bytes) {
        function rightRotate(value, amount) {
            return (value >>> amount) | (value << (32 - amount));
        }
        var K = [
            0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
        ];
        var H = [
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
        ];
        var l = bytes.length;
        var bitLen = l * 8;
        var padLen = ((l + 8) >> 6) + 1;
        var words = new Uint32Array(padLen * 16);
        for (var i = 0; i < l; i++) {
            words[i >> 2] |= (bytes[i] & 0xff) << (24 - (i % 4) * 8);
        }
        words[l >> 2] |= 0x80 << (24 - (l % 4) * 8);
        words[words.length - 2] = Math.floor(bitLen / 0x100000000);
        words[words.length - 1] = bitLen >>> 0;

        var W = new Uint32Array(64);
        for (var chunk = 0; chunk < words.length; chunk += 16) {
            var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
            for (var t = 0; t < 64; t++) {
                if (t < 16) {
                    W[t] = words[chunk + t];
                } else {
                    var s0 = rightRotate(W[t - 15], 7) ^ rightRotate(W[t - 15], 18) ^ (W[t - 15] >>> 3);
                    var s1 = rightRotate(W[t - 2], 17) ^ rightRotate(W[t - 2], 19) ^ (W[t - 2] >>> 10);
                    W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
                }
                var S1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
                var ch = (e & f) ^ ((~e) & g);
                var temp1 = (h + S1 + ch + K[t] + W[t]) >>> 0;
                var S0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
                var maj = (a & b) ^ (a & c) ^ (b & c);
                var temp2 = (S0 + maj) >>> 0;

                h = g; g = f; f = e; e = (d + temp1) >>> 0;
                d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
            }
            H[0] = (H[0] + a) >>> 0;
            H[1] = (H[1] + b) >>> 0;
            H[2] = (H[2] + c) >>> 0;
            H[3] = (H[3] + d) >>> 0;
            H[4] = (H[4] + e) >>> 0;
            H[5] = (H[5] + f) >>> 0;
            H[6] = (H[6] + g) >>> 0;
            H[7] = (H[7] + h) >>> 0;
        }
        var out = new Uint8Array(32);
        for (var k = 0; k < 8; k++) {
            out[k * 4] = (H[k] >>> 24) & 0xff;
            out[k * 4 + 1] = (H[k] >>> 16) & 0xff;
            out[k * 4 + 2] = (H[k] >>> 8) & 0xff;
            out[k * 4 + 3] = H[k] & 0xff;
        }
        return out;
    }

    function hmac_sha256(keyBytes, messageBytes) {
        var block = new Uint8Array(64);
        if (keyBytes.length > 64) {
            block.set(sha256_bytes(keyBytes));
        } else {
            block.set(keyBytes);
        }
        var ipad = new Uint8Array(64);
        var opad = new Uint8Array(64);
        for (var i = 0; i < 64; i++) {
            ipad[i] = block[i] ^ 0x36;
            opad[i] = block[i] ^ 0x5c;
        }
        var inner = new Uint8Array(64 + messageBytes.length);
        inner.set(ipad);
        inner.set(messageBytes, 64);
        var innerHash = sha256_bytes(inner);

        var outer = new Uint8Array(64 + 32);
        outer.set(opad);
        outer.set(innerHash, 64);
        var outerHash = sha256_bytes(outer);

        var hex = '';
        for (var j = 0; j < outerHash.length; j++) {
            var h = outerHash[j].toString(16);
            if (h.length < 2) h = '0' + h;
            hex += h;
        }
        return hex;
    }

    function custom_b64encode(bytes) {
        var res = '';
        var val = 0;
        var bits = -6;
        for (var i = 0; i < bytes.length; i++) {
            val = (val << 8) | bytes[i];
            bits += 8;
            while (bits >= 0) {
                res += CUSTOM_B64_CHARS.charAt((val >> bits) & 0x3F);
                bits -= 6;
            }
        }
        if (bits > -6) {
            res += CUSTOM_B64_CHARS.charAt(((val << 8) >> (bits + 8)) & 0x3F);
        }
        while (res.length % 4 !== 0) {
            res += '.';
        }
        return res;
    }

    function custom_rc4_encrypt(masterKeyBytes, rand4, payloadStr) {
        var S = new Uint8Array(256);
        for (var i = 0; i < 256; i++) S[i] = i;

        var j = 0;
        for (var i = 0; i < 256; i++) {
            j = (j + S[i] + masterKeyBytes[i % 32] + rand4[i % 4]) & 0xFF;
            var tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        }

        var enc = new Uint8Array(payloadStr.length);
        var si = 0, sj = 0, prev = 0x5A;
        for (var k = 0; k < payloadStr.length; k++) {
            si = (si + 1) & 0xFF;
            sj = (sj + S[si]) & 0xFF;
            var tmp = S[si]; S[si] = S[sj]; S[sj] = tmp;

            var t = ((S[si] + S[sj]) ^ prev) & 0xFF;
            var keyByte = S[t];
            var b = payloadStr.charCodeAt(k) & 0xFF;
            var c = b ^ keyByte;
            c = ((c << 3) | (c >> 5)) & 0xFF; // rol8 by 3
            c = (c + prev) & 0xFF;
            prev = c;
            enc[k] = c;
        }

        var tokenRaw = new Uint8Array(4 + enc.length);
        tokenRaw.set(rand4);
        tokenRaw.set(enc, 4);
        return custom_b64encode(tokenRaw);
    }

    function getRandomBytes(len) {
        var buf = new Uint8Array(len);
        if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
            window.crypto.getRandomValues(buf);
        } else {
            for (var i = 0; i < len; i++) {
                buf[i] = Math.floor(Math.random() * 256);
            }
        }
        return buf;
    }

    function getRandomHex(lenBytes) {
        var bytes = getRandomBytes(lenBytes);
        var hex = '';
        for (var i = 0; i < bytes.length; i++) {
            var h = bytes[i].toString(16);
            if (h.length < 2) h = '0' + h;
            hex += h;
        }
        return hex;
    }

    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0;
            var v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    // Server response decryption (Lane Dynamic RC4 + Gzip)
    function rc4_decrypt_data(keyBytes, encBytes) {
        var S = new Uint8Array(256);
        for (var i = 0; i < 256; i++) S[i] = i;
        var j = 0;
        var kLen = keyBytes.length;
        for (var i = 0; i < 256; i++) {
            j = (j + S[i] + keyBytes[i % kLen]) & 0xFF;
            var tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        }
        var si = 0, sj = 0;
        var out = new Uint8Array(encBytes.length);
        for (var p = 0; p < encBytes.length; p++) {
            si = (si + 1) & 0xFF;
            sj = (sj + S[si]) & 0xFF;
            var tmp = S[si]; S[si] = S[sj]; S[sj] = tmp;
            var k = S[(S[si] + S[sj]) & 0xFF];
            out[p] = encBytes[p] ^ k;

            // Dynamic S-box mutation (reverse-engineered from libbnit.so)
            var m = (si + k) & 0xFF;
            S[m] = (S[m] + k) & 0xFF;
        }
        return out;
    }

    var LaneCrypto = {
        generateHeaders: function(method, path, query, body) {
            var masterKeyBytes = new Uint8Array(32);
            for (var i = 0; i < 32; i++) masterKeyBytes[i] = MASTER_KEY.charCodeAt(i);

            var ts = Date.now().toString();
            var nonce = getRandomHex(16);
            var bootId = 'UNKNOWN_BOOT';
            var q = query || '';
            var b = body || '';

            var rawInput = method + ':' + path + ':' + q + ':' + ts + ':' + nonce + ':' + b + ':' + bootId + ':';
            var rawInputBytes = new Uint8Array(rawInput.length);
            for (var i = 0; i < rawInput.length; i++) rawInputBytes[i] = rawInput.charCodeAt(i);

            var hmac = hmac_sha256(masterKeyBytes, rawInputBytes);
            var tracePayload = hmac + '|' + ts + '|' + nonce + '|' + bootId + '||';

            var rand4 = getRandomBytes(4);
            var token = custom_rc4_encrypt(masterKeyBytes, rand4, tracePayload);

            var rand24 = getRandomBytes(24);
            var clientMeta = custom_b64encode(rand24);
            var traceId = generateUUID();

            return {
                'User-Agent': 'okhttp/4.12.0',
                'X-Accept-Red': '1',
                'X-Request-Trace-Id': traceId,
                'X-Client-Meta': clientMeta,
                'X-Core-Token': token
            };
        },

        decryptResponse: function(encArrayBuffer, respNonce) {
            var encBytes = new Uint8Array(encArrayBuffer);
            var keyStr = MASTER_KEY + respNonce;
            var keyBytes = new Uint8Array(keyStr.length);
            for (var i = 0; i < keyStr.length; i++) keyBytes[i] = keyStr.charCodeAt(i);

            var dec = rc4_decrypt_data(keyBytes, encBytes);
            // Check for GZIP header (0x1f 0x8b)
            if (dec.length >= 2 && dec[0] === 0x1f && dec[1] === 0x8b && typeof pako !== 'undefined') {
                try {
                    return pako.inflate(dec, { to: 'string' });
                } catch (e) {
                    console.warn('Gzip inflate warning:', e);
                }
            }
            // fallback utf8 decoder
            return this.bytesToUtf8(dec);
        },

        bytesToUtf8: function(bytes) {
            var out = '', i = 0, len = bytes.length;
            while (i < len) {
                var c = bytes[i++];
                if (c < 128) {
                    out += String.fromCharCode(c);
                } else if (c > 191 && c < 224) {
                    var c2 = bytes[i++];
                    out += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                } else if (c > 223 && c < 240) {
                    var c2 = bytes[i++];
                    var c3 = bytes[i++];
                    out += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                } else {
                    out += String.fromCharCode(c);
                }
            }
            return out;
        }
    };

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = LaneCrypto;
    } else {
        window.LaneCrypto = LaneCrypto;
    }
})(typeof window !== 'undefined' ? window : this);
