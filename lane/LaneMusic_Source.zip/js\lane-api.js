// lane-api.js - Client for Lane Music API
(function(window) {
    'use strict';

    var BASE_URL = 'https://laneapi.com';
    var TOKEN_KEY = 'lane_auth_token';

    var streamCache = {};
    var STREAM_CACHE_TTL = 30 * 60 * 1000; // 30 minutes
    var currentStreamXhr = null;

    var LaneApi = {
        streamCache: streamCache,

        abortStreamRequest: function() {
            if (currentStreamXhr) {
                try {
                    currentStreamXhr.abort();
                    console.log('Aborted in-flight stream request');
                } catch(e) {}
                currentStreamXhr = null;
            }
        },

        getCachedStreamUrl: function(trackId) {
            if (!trackId) return null;
            var item = streamCache[trackId];
            if (item && (Date.now() - item.time < STREAM_CACHE_TTL)) {
                return item.url;
            }
            return null;
        },

        cacheStreamUrl: function(trackId, url) {
            if (trackId && url) {
                streamCache[trackId] = { url: url, time: Date.now() };
            }
        },
        getToken: function() {
            try {
                return localStorage.getItem(TOKEN_KEY) || '';
            } catch (e) {
                return '';
            }
        },

        setToken: function(token) {
            try {
                if (token && typeof token === 'string' && token.trim()) {
                    localStorage.setItem(TOKEN_KEY, token.trim());
                } else {
                    localStorage.removeItem(TOKEN_KEY);
                }
            } catch (e) {}
        },

        isAuthorized: function() {
            var tok = this.getToken();
            return !!(tok && tok.length > 20);
        },

        decodeToken: function(token) {
            var tok = token || this.getToken();
            if (!tok) return null;
            try {
                var parts = tok.split('.');
                if (parts.length < 2) return null;
                var base64Url = parts[1];
                var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                var jsonStr = '';
                if (typeof atob === 'function') {
                    jsonStr = decodeURIComponent(escape(atob(base64)));
                } else {
                    return null;
                }
                return JSON.parse(jsonStr);
            } catch(e) {
                return null;
            }
        },

        request: function(method, path, queryParams, bodyData, isStream) {
            var self = this;
            return new Promise(function(resolve, reject) {
                var queryStr = '';
                if (queryParams) {
                    var parts = [];
                    // Always sort query keys alphabetically for valid bnit HMAC signatures!
                    var keys = Object.keys(queryParams).sort();
                    for (var i = 0; i < keys.length; i++) {
                        var k = keys[i];
                        if (queryParams.hasOwnProperty(k) && queryParams[k] !== undefined && queryParams[k] !== null) {
                            parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(queryParams[k]));
                        }
                    }
                    queryStr = parts.join('&');
                }

                var fullUrl = BASE_URL + path + (queryStr ? ('?' + queryStr) : '');
                var bodyStr = bodyData ? JSON.stringify(bodyData) : '';

                var bnitHeaders = LaneCrypto.generateHeaders(method, path, queryStr, bodyStr);

                var xhr = new XMLHttpRequest();
                if (isStream) {
                    currentStreamXhr = xhr;
                }
                xhr.open(method, fullUrl, true);
                xhr.responseType = 'arraybuffer';

                // Set headers
                for (var h in bnitHeaders) {
                    if (bnitHeaders.hasOwnProperty(h)) {
                        xhr.setRequestHeader(h, bnitHeaders[h]);
                    }
                }

                var userToken = self.getToken();
                if (userToken) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + userToken);
                }

                if (bodyStr) {
                    xhr.setRequestHeader('Content-Type', 'application/json');
                }

                xhr.onload = function() {
                    if (currentStreamXhr === xhr) currentStreamXhr = null;
                    var status = xhr.status;
                    var respNonce = xhr.getResponseHeader('X-Resp-Nonce');
                    var responseText = '';

                    if (xhr.response) {
                        if (respNonce) {
                            try {
                                responseText = LaneCrypto.decryptResponse(xhr.response, respNonce);
                            } catch (e) {
                                console.error('Failed to decrypt response:', e);
                            }
                        } else {
                            try {
                                var bytes = new Uint8Array(xhr.response);
                                if (typeof TextDecoder !== 'undefined') {
                                    responseText = new TextDecoder('utf-8').decode(bytes);
                                } else {
                                    responseText = LaneCrypto.bytesToUtf8(bytes);
                                }
                            } catch (e) {
                                responseText = LaneCrypto.bytesToUtf8(new Uint8Array(xhr.response));
                            }
                        }
                    }

                    if (status >= 200 && status < 300) {
                        try {
                            var json = JSON.parse(responseText);
                            resolve(json);
                        } catch (e) {
                            resolve(responseText);
                        }
                    } else if (status === 401) {
                        reject({ status: 401, message: 'Unauthorized (требуется токен авторизации)', raw: responseText });
                    } else {
                        reject({ status: status, message: 'HTTP Error ' + status, raw: responseText });
                    }
                };

                xhr.onerror = function() {
                    if (currentStreamXhr === xhr) currentStreamXhr = null;
                    reject({ status: 0, message: 'Сетевая ошибка или отсутствие подключения' });
                };

                xhr.onabort = function() {
                    if (currentStreamXhr === xhr) currentStreamXhr = null;
                    reject({ status: 0, message: 'Запрос отменен', aborted: true });
                };

                xhr.ontimeout = function() {
                    if (currentStreamXhr === xhr) currentStreamXhr = null;
                    reject({ status: 0, message: 'Таймаут запроса к серверу' });
                };

                xhr.timeout = 15000;
                xhr.send(bodyStr || null);
            });
        },

        // API Methods
        getHomeFeed: function() {
            return this.request('GET', '/feed/home');
        },

        search: function(query) {
            return this.request('GET', '/platforms/search', { platform: 'all', q: query });
        },

        getStreamUrl: function(trackId, platform) {
            var self = this;
            if (!trackId) return Promise.reject({ message: 'No trackId' });

            var cached = this.getCachedStreamUrl(trackId);
            if (cached) {
                console.log('Stream URL retrieved from 0ms cache for trackId:', trackId);
                return Promise.resolve({ url: cached, fromCache: true });
            }

            this.abortStreamRequest();

            var params = { trackId: trackId };
            if (platform) {
                params.platform = platform;
            }
            return this.request('GET', '/track/stream', params, null, true).then(function(res) {
                var streamUrl = '';
                if (typeof res === 'string') streamUrl = res;
                else if (res && res.url) streamUrl = res.url;
                else if (res && res.streamUrl) streamUrl = res.streamUrl;
                else if (res && res.data && res.data.url) streamUrl = res.data.url;

                if (streamUrl) {
                    self.cacheStreamUrl(trackId, streamUrl);
                }
                return res;
            });
        },

        getTrackComments: function(trackId, page, pageSize) {
            var p = page || 1;
            var ps = pageSize || 30;
            return this.request('GET', '/track/' + encodeURIComponent(trackId) + '/comments', { page: p, pageSize: ps }).catch(function() {
                return LaneApi.request('GET', '/comment/track', { trackId: trackId, page: p, pageSize: ps });
            });
        },

        postTrackComment: function(trackId, text) {
            return this.request('POST', '/comment/track', null, { trackId: trackId, text: text });
        },

        likeComment: function(commentId) {
            return this.request('POST', '/comment/' + encodeURIComponent(commentId) + '/like');
        },

        getPlaylistTracks: function(playlistId) {
            return this.request('GET', '/playlist/' + encodeURIComponent(playlistId) + '/tracks');
        },

        getUserInfo: function(laneId) {
            var lid = laneId;
            if (!lid) {
                var payload = this.decodeToken();
                if (payload && payload.laneId) {
                    lid = payload.laneId;
                }
            }
            if (!lid) {
                return Promise.reject({ status: 400, message: 'No laneId available' });
            }
            return this.request('GET', '/user-info', { laneId: lid });
        },

        getUserTracks: function() {
            return this.request('GET', '/user/tracks');
        },

        getUserPlaylists: function() {
            return this.request('GET', '/user/playlists');
        },

        getUserRecent: function() {
            return this.request('GET', '/user/recent');
        },

        getUserAlbums: function() {
            return this.request('GET', '/user/albums');
        },

        getUserArtists: function() {
            return this.request('GET', '/user/artists');
        },

        likeTrack: function(trackId) {
            return this.request('POST', '/user/tracks', null, { ids: [trackId] });
        }
    };

    window.LaneApi = LaneApi;
})(window);
