// app.js - Main Application Logic for Lumia 650 (LANE Metro Red Client)
(function() {
    'use strict';

    // Polyfills for EdgeHTML 15
    if (window.NodeList && !NodeList.prototype.forEach) {
        NodeList.prototype.forEach = function(callback, thisArg) {
            for (var i = 0; i < this.length; i++) callback.call(thisArg, this[i], i, this);
        };
    }
    if (!Array.prototype.findIndex) {
        Array.prototype.findIndex = function(predicate) {
            for (var i = 0; i < this.length; i++) {
                if (predicate(this[i], i, this)) return i;
            }
            return -1;
        };
    }

    var currentTabIndex = 0;
    var tabTargets = ['page-library', 'page-home', 'page-playlists', 'page-search', 'page-settings'];
    var tabTitles = {
        'page-library': 'моя музыка',
        'page-home': 'главная',
        'page-playlists': 'плейлисты',
        'page-search': 'поиск',
        'page-settings': 'параметры'
    };

    // In-memory & Persistent Cache for 0ms Instant Loading
    var cachedHomeTracks = null;
    var cachedLibraryTracks = null;
    var cachedPlaylists = null;

    document.addEventListener('DOMContentLoaded', function() {
        try {
            initWindowsNativeIntegration();
            Player.init();
            initNavigation();
            initSplitView();
            initTouchGestures();
            initEqualizerUI();
            initAuthUI();
            initSearch();
            initPlayerModals();
            initPlaylistsUI();
            initMixesUI();
            initOtaUpdater();
            
            // 1. Instant 0ms load library from persistent storage
            loadInstantCachedLibrary();
            updateGreeting();
            
            // 2. Fetch fresh library in background immediately
            loadLibrary(false);
            
            // Fetch playlists in background for instant mixes carousel
            LaneApi.getUserPlaylists().then(function(res) {
                var list = Array.isArray(res) ? res : (res.items || res.playlists || []);
                cachedPlaylists = list;
                if (typeof renderMixesAndSections === 'function') renderMixesAndSections();
            }).catch(function() {});
            
            // 3. Preload home feed slightly deferred so library gets full network priority
            setTimeout(function() {
                loadHomeFeed();
            }, 400);
        } catch(e) {
            console.error('App init error:', e);
        }
    });

    // Native Windows 10 Mobile Platform Integration
    function initWindowsNativeIntegration() {
        if (typeof Windows === 'undefined' || !Windows.UI) return;

        // 1. Show Native Windows 10 Mobile Status Bar
        try {
            if (Windows.UI.ViewManagement) {
                var appView = Windows.UI.ViewManagement.ApplicationView.getForCurrentView();
                if (appView && appView.setDesiredBoundsMode) {
                    appView.setDesiredBoundsMode(Windows.UI.ViewManagement.ApplicationViewBoundsMode.useVisible);
                }

                if (Windows.UI.ViewManagement.StatusBar) {
                    var statusBar = Windows.UI.ViewManagement.StatusBar.getForCurrentView();
                    if (statusBar) {
                        statusBar.showAsync();
                        statusBar.backgroundColor = { a: 255, r: 0, g: 0, b: 0 };
                        statusBar.backgroundOpacity = 1;
                        statusBar.foregroundColor = { a: 255, r: 255, g: 255, b: 255 };
                    }
                }
            }
        } catch (e) {
            console.warn('Native StatusBar init error:', e);
        }

        // 2. Hardware / Virtual Back Button handling
        try {
            if (Windows.UI.Core && Windows.UI.Core.SystemNavigationManager) {
                var navManager = Windows.UI.Core.SystemNavigationManager.getForCurrentView();
                navManager.addEventListener('backrequested', function(args) {
                    var commentsModal = document.getElementById('commentsModalBackdrop');
                    if (commentsModal && (commentsModal.classList.contains('active') || commentsModal.classList.contains('visible'))) {
                        commentsModal.classList.remove('active');
                        commentsModal.classList.remove('visible');
                        args.handled = true;
                        return;
                    }

                    var fullModal = document.getElementById('fullPlayerModal');
                    if (fullModal && fullModal.classList.contains('active')) {
                        fullModal.classList.remove('active');
                        args.handled = true;
                        return;
                    }

                    var eqModal = document.getElementById('eqModalBackdrop');
                    if (eqModal && eqModal.classList.contains('active')) {
                        eqModal.classList.remove('active');
                        args.handled = true;
                        return;
                    }

                    var guideModal = document.getElementById('loginGuideModalBackdrop');
                    if (guideModal && (guideModal.classList.contains('active') || guideModal.classList.contains('visible'))) {
                        guideModal.classList.remove('active');
                        guideModal.classList.remove('visible');
                        args.handled = true;
                        return;
                    }

                    var splitView = document.getElementById('splitViewPane');
                    if (splitView && splitView.classList.contains('active')) {
                        closeSplitView();
                        args.handled = true;
                        return;
                    }

                    var playlistSection = document.getElementById('playlistTracksSection');
                    if (playlistSection && playlistSection.style.display !== 'none') {
                        playlistSection.style.display = 'none';
                        document.getElementById('playlistsContainer').style.display = 'grid';
                        args.handled = true;
                        return;
                    }

                    if (currentTabIndex !== 0) {
                        switchToTab(0);
                        args.handled = true;
                        return;
                    }
                });
            }
        } catch(e) {}
    }

    // 1. SplitView Burger Navigation
    function initSplitView() {
        var burgerBtn = document.getElementById('burgerBtn');
        var pane = document.getElementById('splitViewPane');
        var overlay = document.getElementById('splitViewOverlay');
        var items = document.querySelectorAll('.splitview-item');

        if (burgerBtn) {
            burgerBtn.addEventListener('click', function() {
                toggleSplitView();
            });
        }

        if (overlay) {
            overlay.addEventListener('click', function() {
                closeSplitView();
            });
        }

        for (var i = 0; i < items.length; i++) {
            (function(item) {
                item.addEventListener('click', function() {
                    var targetId = item.getAttribute('data-target');
                    if (targetId) {
                        var idx = tabTargets.indexOf(targetId);
                        if (idx !== -1) switchToTab(idx);
                        closeSplitView();
                    }
                });
            })(items[i]);
        }
    }

    function toggleSplitView() {
        var pane = document.getElementById('splitViewPane');
        var overlay = document.getElementById('splitViewOverlay');
        if (pane) pane.classList.toggle('active');
        if (overlay) overlay.classList.toggle('active');
    }

    function closeSplitView() {
        var pane = document.getElementById('splitViewPane');
        var overlay = document.getElementById('splitViewOverlay');
        if (pane) pane.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
    }

    // 2. Metro Pivot Navigation
    function initNavigation() {
        var headerItems = document.querySelectorAll('.pivot-header-item');
        for (var i = 0; i < headerItems.length; i++) {
            (function(item, idx) {
                item.addEventListener('click', function() {
                    switchToTab(idx);
                });
            })(headerItems[i], i);
        }
    }

    function switchToTab(index) {
        if (index < 0 || index >= tabTargets.length) return;
        currentTabIndex = index;
        var targetId = tabTargets[index];

        var topTitle = document.getElementById('topSectionTitle');
        if (topTitle && tabTitles[targetId]) {
            topTitle.textContent = tabTitles[targetId];
        }

        var headerItems = document.querySelectorAll('.pivot-header-item');
        for (var i = 0; i < headerItems.length; i++) {
            if (i === index) headerItems[i].classList.add('active');
            else headerItems[i].classList.remove('active');
        }

        var splitItems = document.querySelectorAll('.splitview-item');
        for (var s = 0; s < splitItems.length; s++) {
            if (splitItems[s].getAttribute('data-target') === targetId) splitItems[s].classList.add('active');
            else splitItems[s].classList.remove('active');
        }

        var pages = document.querySelectorAll('.pivot-page');
        for (var j = 0; j < pages.length; j++) {
            if (pages[j].id === targetId) pages[j].classList.add('active');
            else pages[j].classList.remove('active');
        }

        // Action per tab
        if (targetId === 'page-library') {
            loadLibrary();
        } else if (targetId === 'page-playlists') {
            loadPlaylists();
        } else if (targetId === 'page-home') {
            loadHomeFeed();
        }
    }

    function switchTab(index) {
        switchToTab(index);
    }

    // 3. Touch Swipe Navigation
    function initTouchGestures() {
        var touchStartX = 0, touchStartY = 0, touchEndX = 0, touchEndY = 0;
        var isInsideHorizontalScroll = false;
        var pivotViewport = document.getElementById('pivotViewport');
        if (!pivotViewport) return;

        pivotViewport.addEventListener('touchstart', function(e) {
            if (e.touches && e.touches.length > 0) {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                isInsideHorizontalScroll = false;
                var el = e.target;
                while (el && el !== pivotViewport) {
                    if (el.classList && (el.classList.contains('recent-mixes-scroll') || el.classList.contains('metro-slider') || el.classList.contains('eq-presets-row'))) {
                        isInsideHorizontalScroll = true;
                        break;
                    }
                    el = el.parentElement;
                }
            }
        }, { passive: true });

        pivotViewport.addEventListener('touchend', function(e) {
            if (e.changedTouches && e.changedTouches.length > 0) {
                touchEndX = e.changedTouches[0].clientX;
                touchEndY = e.changedTouches[0].clientY;
                handleSwipeGesture();
            }
        }, { passive: true });

        function handleSwipeGesture() {
            if (isInsideHorizontalScroll) return; // Do not switch tabs when scrolling horizontal carousel!
            var diffX = touchEndX - touchStartX;
            var diffY = touchEndY - touchStartY;
            if (Math.abs(diffX) > 65 && Math.abs(diffX) > Math.abs(diffY) * 1.6) {
                if (diffX < 0) {
                    if (currentTabIndex < tabTargets.length - 1) switchToTab(currentTabIndex + 1);
                } else {
                    if (currentTabIndex > 0) switchToTab(currentTabIndex - 1);
                }
            }
        }
    }

    // 4. Equalizer UI & Bass Boost
    function initEqualizerUI() {
        try {
            var openTopBtn = document.getElementById('openEqBtnTop');
            var openFullBtn = document.getElementById('fullEqBtn');
            var openSplitBtn = document.getElementById('splitViewEqTrigger');
            var closeBtn = document.getElementById('closeEqBtn');
            var backdrop = document.getElementById('eqModalBackdrop');
            var bassToggle = document.getElementById('bassBoostToggle');

            function openEq() {
                if (typeof Player.initEqualizer === 'function') {
                    Player.initEqualizer();
                }
                if (backdrop) backdrop.classList.add('active');
                closeSplitView();
            }

            function closeEq() {
                if (backdrop) backdrop.classList.remove('active');
            }

            if (openTopBtn) openTopBtn.addEventListener('click', openEq);
            if (openFullBtn) openFullBtn.addEventListener('click', openEq);
            if (openSplitBtn) openSplitBtn.addEventListener('click', openEq);
            if (closeBtn) closeBtn.addEventListener('click', closeEq);
            if (backdrop) {
                backdrop.addEventListener('click', function(e) {
                    if (e.target === backdrop) closeEq();
                });
            }

            if (bassToggle) {
                try {
                    bassToggle.checked = (localStorage.getItem('lane_bass_boost') === '1');
                } catch(e) {}
                bassToggle.addEventListener('change', function() {
                    try {
                        Player.setBassBoost(this.checked);
                        Player.showNotification(this.checked ? 'BASS BOOST: ВКЛ' : 'BASS BOOST: ВЫКЛ');
                    } catch(ex) {}
                });
            }

            // Sliders
            var s60 = document.getElementById('eqSlider60');
            var s250 = document.getElementById('eqSlider250');
            var s1k = document.getElementById('eqSlider1k');
            var s4k = document.getElementById('eqSlider4k');

            function wireSlider(slider, labelId, bandIdx) {
                if (!slider) return;
                slider.addEventListener('input', function() {
                    try {
                        var val = parseFloat(this.value) || 0;
                        var lbl = document.getElementById(labelId);
                        if (lbl) lbl.innerText = (val > 0 ? ('+' + val) : val) + ' dB';
                        Player.setBandGain(bandIdx, val);
                    } catch(ex) {}
                });
            }

            wireSlider(s60, 'eqVal60', 0);
            wireSlider(s250, 'eqVal250', 1);
            wireSlider(s1k, 'eqVal1k', 2);
            wireSlider(s4k, 'eqVal4k', 3);

            // Presets
            var presetBtns = document.querySelectorAll('.eq-preset-btn');
            try {
                var currentPreset = localStorage.getItem('lane_eq_preset') || 'normal';
                for (var b = 0; b < presetBtns.length; b++) {
                    if (presetBtns[b].getAttribute('data-preset') === currentPreset) {
                        presetBtns[b].classList.add('active');
                    } else {
                        presetBtns[b].classList.remove('active');
                    }
                }
            } catch(e) {}

            for (var p = 0; p < presetBtns.length; p++) {
                (function(btn) {
                    btn.addEventListener('click', function() {
                        try {
                            for (var k = 0; k < presetBtns.length; k++) presetBtns[k].classList.remove('active');
                            btn.classList.add('active');
                            var preset = btn.getAttribute('data-preset');
                            var vals = Player.applyPreset(preset);
                            if (vals) {
                                if (s60) { s60.value = vals[0]; document.getElementById('eqVal60').innerText = (vals[0]>0?'+':'')+vals[0]+' dB'; }
                                if (s250) { s250.value = vals[1]; document.getElementById('eqVal250').innerText = (vals[1]>0?'+':'')+vals[1]+' dB'; }
                                if (s1k) { s1k.value = vals[2]; document.getElementById('eqVal1k').innerText = (vals[2]>0?'+':'')+vals[2]+' dB'; }
                                if (s4k) { s4k.value = vals[3]; document.getElementById('eqVal4k').innerText = (vals[3]>0?'+':'')+vals[3]+' dB'; }
                            }
                        } catch(ex) {}
                    });
                })(presetBtns[p]);
            }
        } catch(e) {
            console.warn('initEqualizerUI error:', e);
        }
    }

    // 5. Auth & Settings UI
    function initAuthUI() {
        var tokenInput = document.getElementById('tokenInput');
        var saveBtn = document.getElementById('saveTokenBtn');
        var logoutBtn = document.getElementById('logoutBtn');
        var pasteTokenBtn = document.getElementById('pasteTokenBtn');
        var openGuideBtn = document.getElementById('openLoginGuideBtn');
        var closeGuideBtn = document.getElementById('closeLoginGuideBtn');
        var guideModal = document.getElementById('loginGuideModalBackdrop');
        var profileName = document.getElementById('profileUserName');
        var splitName = document.getElementById('splitViewUserName');
        var profileSubtext = document.getElementById('profileStatusSubtext');
        var splitAvatar = document.getElementById('splitViewAvatar');
        var splitUserHeader = document.getElementById('splitViewUserHeader');

        // Modal Guide handlers
        function showGuide() {
            if (guideModal) {
                guideModal.classList.add('active');
                guideModal.classList.add('visible');
            }
        }
        function hideGuide() {
            if (guideModal) {
                guideModal.classList.remove('active');
                guideModal.classList.remove('visible');
            }
        }
        if (openGuideBtn) openGuideBtn.addEventListener('click', showGuide);
        if (closeGuideBtn) closeGuideBtn.addEventListener('click', hideGuide);
        if (guideModal) {
            guideModal.addEventListener('click', function(e) {
                if (e.target === guideModal) hideGuide();
            });
        }

        var boostyBtn = document.getElementById('openBoostyBtn');
        if (boostyBtn) {
            boostyBtn.addEventListener('click', function() {
                try {
                    if (typeof Windows !== 'undefined' && Windows.System && Windows.System.Launcher) {
                        Windows.System.Launcher.launchUriAsync(new Windows.Foundation.Uri('https://boosty.to/prosh1vka'));
                    } else {
                        window.open('https://boosty.to/prosh1vka', '_blank');
                    }
                } catch(e) {
                    window.location.href = 'https://boosty.to/prosh1vka';
                }
            });
        }
        if (splitUserHeader) {
            splitUserHeader.addEventListener('click', function() {
                if (!LaneApi.isAuthorized()) {
                    showGuide();
                } else {
                    switchTab(4); // go to settings
                    closeSplitView();
                }
            });
        }

        function updateAuthBadge() {
            var token = LaneApi.getToken();
            if (token && LaneApi.isAuthorized()) {
                if (logoutBtn) logoutBtn.style.display = 'inline-block';
                if (tokenInput) tokenInput.value = token;
                if (profileSubtext) profileSubtext.innerText = 'Авторизован (токен сохранён)';

                // Fetch real user info from Lane API
                LaneApi.getUserInfo().then(function(u) {
                    if (u) {
                        var info = (u.data && typeof u.data === 'object') ? u.data : ((u.user && typeof u.user === 'object') ? u.user : u);
                        var name = info.displayedName || info.userName || info.username || info.name || info.nickname || '';
                        var avatar = info.avatarUrl || info.avatar || info.photoUrl || info.imageUrl || '';

                        if (name && !isUuid(name)) {
                            if (profileName) profileName.innerText = name;
                            if (splitName) splitName.innerText = name;
                            try {
                                localStorage.setItem('lane_user_profile', JSON.stringify({ name: name, userName: name }));
                            } catch(ex) {}
                            updateGreeting();
                        }
                        if (avatar && splitAvatar) {
                            splitAvatar.src = normalizeCoverUrl(avatar);
                        }
                    }
                }).catch(function(e) {
                    console.warn('getUserInfo failed:', e);
                });
            } else {
                if (logoutBtn) logoutBtn.style.display = 'none';
                if (tokenInput) tokenInput.value = '';
                if (profileName) profileName.innerText = 'Не авторизован';
                if (splitName) splitName.innerText = 'Гость';
                if (splitAvatar) splitAvatar.src = 'assets/Square44x44Logo.png';
                if (profileSubtext) profileSubtext.innerText = 'Токен не задан. Нажмите «Как получить токен»';
            }
        }

        // Custom Nickname handler
        var nickInput = document.getElementById('customNickInput');
        var saveNickBtn = document.getElementById('saveNickBtn');
        if (nickInput) {
            try {
                nickInput.value = localStorage.getItem('lane_custom_nickname') || '';
            } catch(e) {}
        }
        if (saveNickBtn && nickInput) {
            saveNickBtn.addEventListener('click', function() {
                var nick = nickInput.value.trim();
                try {
                    if (nick) {
                        localStorage.setItem('lane_custom_nickname', nick);
                        Player.showNotification('Никнейм сохранён: ' + nick);
                    } else {
                        localStorage.removeItem('lane_custom_nickname');
                        Player.showNotification('Никнейм сброшен');
                    }
                } catch(e) {}
                updateGreeting();
            });
        }

        updateAuthBadge();

        function applyToken(val) {
            if (!val || !val.trim()) {
                Player.showNotification('Токен пуст');
                return;
            }
            LaneApi.setToken(val.trim());
            cachedLibraryTracks = null;
            cachedHomeTracks = null;
            cachedPlaylists = null;
            try { localStorage.removeItem('lane_library_cache'); } catch(e) {}
            updateAuthBadge();
            Player.showNotification('Токен сохранён!');
            loadLibrary(true);
            loadHomeFeed(true);
        }

        if (pasteTokenBtn) {
            pasteTokenBtn.addEventListener('click', function() {
                try {
                    if (navigator.clipboard && navigator.clipboard.readText) {
                        navigator.clipboard.readText().then(function(clipText) {
                            if (clipText && clipText.trim()) {
                                if (tokenInput) tokenInput.value = clipText.trim();
                                applyToken(clipText.trim());
                            } else {
                                promptFallback();
                            }
                        }).catch(promptFallback);
                    } else {
                        promptFallback();
                    }
                } catch(e) {
                    promptFallback();
                }

                function promptFallback() {
                    var val = prompt('Вставьте JWT токен LANE (начинается с eyJ...):');
                    if (val && val.trim()) {
                        if (tokenInput) tokenInput.value = val.trim();
                        applyToken(val.trim());
                    }
                }
            });
        }

        if (saveBtn) {
            saveBtn.addEventListener('click', function() {
                var val = tokenInput ? tokenInput.value.trim() : '';
                if (!val) {
                    Player.showNotification('Введите или вставьте токен');
                    return;
                }
                applyToken(val);
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                LaneApi.setToken('');
                cachedLibraryTracks = null;
                cachedHomeTracks = null;
                cachedPlaylists = null;
                try { localStorage.removeItem('lane_library_cache'); } catch(e) {}
                updateAuthBadge();
                Player.showNotification('Вы вышли из аккаунта');
                loadLibrary(true);
                loadHomeFeed(true);
            });
        }
    }

    // 6. Search UI
    function initSearch() {
        var input = document.getElementById('searchInput');
        var btn = document.getElementById('searchBtn');

        function doSearch() {
            var q = input ? input.value.trim() : '';
            if (!q) return;

            var container = document.getElementById('searchResultsList');
            if (container) {
                container.innerHTML = '<div class="metro-empty-state">поиск...</div>';
            }

            LaneApi.search(q).then(function(res) {
                var tracks = extractTracks(res);
                if (tracks.length === 0) {
                    if (container) container.innerHTML = '<div class="metro-empty-state">ничего не найдено</div>';
                    return;
                }
                renderTrackList(container, tracks);
            }).catch(function(err) {
                console.error('Search error:', err);
                if (container) {
                    container.innerHTML = '<div style="text-align:center; padding: 40px 10px; color:#ef4444; font-size:13px;">' + (err.message || 'Ошибка поиска') + '</div>';
                }
            });
        }

        if (btn) btn.addEventListener('click', doSearch);
        if (input) {
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') doSearch();
            });
        }
    }

    // 7. Instant Persistent Library Loading (0 ms startup!)
    function loadInstantCachedLibrary() {
        try {
            var saved = localStorage.getItem('lane_library_cache');
            if (saved) {
                var tracks = JSON.parse(saved);
                if (Array.isArray(tracks) && tracks.length > 0) {
                    cachedLibraryTracks = tracks;
                    var container = document.getElementById('libraryTracksList');
                    if (container) renderTrackList(container, tracks);
                }
            }
        } catch(e) {}
    }

    // 8. Home Feed (Реальные персональные рекомендации и миксы)
    function loadHomeFeed(forceRefresh) {
        var container = document.getElementById('homeTracksList');
        if (!container) return;

        if (cachedHomeTracks && !forceRefresh) {
            renderTrackList(container, cachedHomeTracks);
            return;
        }

        container.innerHTML = '<div class="metro-empty-state">загрузка рекомендаций...</div>';

        // Load real recommendations from /feed/home
        LaneApi.getHomeFeed().then(function(res) {
            if (res && res.sections && Array.isArray(res.sections)) {
                var chosenPl = null;
                var sectionTitle = '';
                for (var s = 0; s < res.sections.length; s++) {
                    var sec = res.sections[s];
                    if (sec.content && sec.content.length > 0) {
                        for (var c = 0; c < sec.content.length; c++) {
                            var item = sec.content[c];
                            if (item.playlist && item.playlist.playlistId) {
                                chosenPl = item.playlist;
                                sectionTitle = sec.title;
                                break;
                            }
                        }
                    }
                    if (chosenPl) break;
                }

                if (chosenPl && chosenPl.playlistId) {
                    var homeSub = document.getElementById('homeSubheading');
                    if (homeSub) {
                        var name = chosenPl.playlistName || sectionTitle || 'рекомендации дня';
                        homeSub.textContent = 'рекомендации: ' + name;
                    }

                    return LaneApi.getPlaylistTracks(chosenPl.playlistId).then(function(plRes) {
                        var tracks = extractTracks(plRes);
                        if (tracks.length > 0) {
                            cachedHomeTracks = tracks;
                            renderTrackList(container, tracks);
                        } else {
                            renderFallbackTracks(container);
                        }
                    });
                }
            }

            renderFallbackTracks(container);
        }).catch(function(err) {
            console.warn('Home feed error:', err);
            renderFallbackTracks(container);
        });
    }

    // 8.5 Mixes & Daily Collections (Добрый день Mix, Недавно прослушано, etc.)
    function getUserDisplayName() {
        var userName = '';
        try {
            var custom = localStorage.getItem('lane_custom_nickname');
            if (custom && custom.trim() && !isUuid(custom)) {
                userName = custom.trim();
            }
        } catch(e) {}

        if (!userName) {
            try {
                var cachedProfile = JSON.parse(localStorage.getItem('lane_user_profile') || '{}');
                var cName = cachedProfile.displayedName || cachedProfile.userName || cachedProfile.username || cachedProfile.name || '';
                if (cName && !isUuid(cName)) {
                    userName = cName;
                }
            } catch(e) {}
        }

        if (!userName) {
            var splitName = document.getElementById('splitViewUserName');
            if (splitName && splitName.innerText) {
                var sTxt = splitName.innerText.trim();
                if (sTxt !== 'Гость' && sTxt !== 'Не авторизован' && sTxt !== 'LANE User' && !isUuid(sTxt)) {
                    userName = sTxt;
                }
            }
        }

        if (!userName) {
            var payload = LaneApi.decodeToken();
            if (payload) {
                var candidate = payload.displayedName || payload.userName || payload.username || payload.name || '';
                if (candidate && !isUuid(candidate)) {
                    userName = candidate;
                }
            }
        }

        return userName || 'prosh1vka';
    }

    function getMixArtworkSvg(type) {
        if (type === 'day') {
            return '<svg width="100%" height="100%" viewBox="0 0 145 145" xmlns="http://www.w3.org/2000/svg">' +
                '<defs>' +
                '  <radialGradient id="gradDay" cx="50%" cy="40%" r="65%">' +
                '    <stop offset="0%" stop-color="#3b2b1a"/>' +
                '    <stop offset="60%" stop-color="#18130e"/>' +
                '    <stop offset="100%" stop-color="#0e0c0a"/>' +
                '  </radialGradient>' +
                '</defs>' +
                '<rect width="145" height="145" fill="url(#gradDay)"/>' +
                '<text x="72" y="32" fill="#523d24" opacity="0.35" font-size="16" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="2">GOOD DAY</text>' +
                '<text x="72" y="125" fill="#523d24" opacity="0.35" font-size="16" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="3">MIX</text>' +
                '<circle cx="72" cy="70" r="17" fill="none" stroke="#f6c278" stroke-width="4.5"/>' +
                '<line x1="72" y1="40" x2="72" y2="46" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="72" y1="94" x2="72" y2="100" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="42" y1="70" x2="48" y2="70" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="96" y1="70" x2="102" y2="70" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="51" y1="49" x2="55" y2="53" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="89" y1="87" x2="93" y2="91" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="93" y1="49" x2="89" y2="53" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<line x1="55" y1="87" x2="51" y2="91" stroke="#f6c278" stroke-width="4.5" stroke-linecap="round"/>' +
                '<text x="135" y="136" fill="#c69550" font-size="8.5" font-weight="700" font-family="sans-serif" text-anchor="end" letter-spacing="1">LANE</text>' +
                '</svg>';
        } else if (type === 'evening') {
            return '<svg width="100%" height="100%" viewBox="0 0 145 145" xmlns="http://www.w3.org/2000/svg">' +
                '<defs>' +
                '  <radialGradient id="gradEve" cx="50%" cy="40%" r="65%">' +
                '    <stop offset="0%" stop-color="#3d2616"/>' +
                '    <stop offset="60%" stop-color="#1a110a"/>' +
                '    <stop offset="100%" stop-color="#0d0805"/>' +
                '  </radialGradient>' +
                '</defs>' +
                '<rect width="145" height="145" fill="url(#gradEve)"/>' +
                '<text x="72" y="32" fill="#52321c" opacity="0.35" font-size="14" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="1">GOOD EVENING</text>' +
                '<text x="72" y="125" fill="#52321c" opacity="0.35" font-size="16" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="3">MIX</text>' +
                '<path d="M 62 48 A 18 18 0 1 0 85 76 A 21 21 0 0 1 62 48 Z" fill="#e89d48"/>' +
                '<path d="M 50 82 A 9 9 0 0 1 65 74 A 13 13 0 0 1 88 76 A 8 8 0 0 1 95 86 A 7 7 0 0 1 88 92 L 53 92 A 8 8 0 0 1 50 82 Z" fill="#ca7f2d" opacity="0.95"/>' +
                '<polygon points="90,48 92,53 97,55 92,57 90,62 88,57 83,55 88,53" fill="#f8c37d"/>' +
                '<text x="135" y="136" fill="#c69550" font-size="8.5" font-weight="700" font-family="sans-serif" text-anchor="end" letter-spacing="1">LANE</text>' +
                '</svg>';
        } else if (type === 'night') {
            return '<svg width="100%" height="100%" viewBox="0 0 145 145" xmlns="http://www.w3.org/2000/svg">' +
                '<defs>' +
                '  <radialGradient id="gradNight" cx="50%" cy="40%" r="65%">' +
                '    <stop offset="0%" stop-color="#241f3d"/>' +
                '    <stop offset="60%" stop-color="#120f21"/>' +
                '    <stop offset="100%" stop-color="#08070e"/>' +
                '  </radialGradient>' +
                '</defs>' +
                '<rect width="145" height="145" fill="url(#gradNight)"/>' +
                '<text x="72" y="32" fill="#3f386b" opacity="0.35" font-size="14" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="2">GOOD NIGHT</text>' +
                '<text x="72" y="125" fill="#3f386b" opacity="0.35" font-size="16" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="3">MIX</text>' +
                '<path d="M 64 46 A 20 20 0 1 0 90 76 A 23 23 0 0 1 64 46 Z" fill="#9c8feb"/>' +
                '<polygon points="86,44 87.5,48 92,49.5 87.5,51 86,55 84.5,51 80,49.5 84.5,48" fill="#e0dcff"/>' +
                '<polygon points="52,70 53,73 56,74 53,75 52,78 51,75 48,74 51,73" fill="#c7bfff"/>' +
                '<text x="135" y="136" fill="#9c8feb" font-size="8.5" font-weight="700" font-family="sans-serif" text-anchor="end" letter-spacing="1">LANE</text>' +
                '</svg>';
        } else {
            return '<svg width="100%" height="100%" viewBox="0 0 145 145" xmlns="http://www.w3.org/2000/svg">' +
                '<defs>' +
                '  <radialGradient id="gradMorn" cx="50%" cy="40%" r="65%">' +
                '    <stop offset="0%" stop-color="#3d2a18"/>' +
                '    <stop offset="60%" stop-color="#1c130b"/>' +
                '    <stop offset="100%" stop-color="#0e0a06"/>' +
                '  </radialGradient>' +
                '</defs>' +
                '<rect width="145" height="145" fill="url(#gradMorn)"/>' +
                '<text x="72" y="32" fill="#593b1d" opacity="0.35" font-size="13" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="1">GOOD MORNING</text>' +
                '<text x="72" y="125" fill="#593b1d" opacity="0.35" font-size="16" font-weight="900" font-family="sans-serif" text-anchor="middle" letter-spacing="3">MIX</text>' +
                '<line x1="38" y1="84" x2="106" y2="84" stroke="#f6c278" stroke-width="3" stroke-linecap="round"/>' +
                '<path d="M 52 84 A 20 20 0 0 1 92 84 Z" fill="#f6c278"/>' +
                '<line x1="72" y1="46" x2="72" y2="54" stroke="#f6c278" stroke-width="3.5" stroke-linecap="round"/>' +
                '<line x1="52" y1="56" x2="58" y2="62" stroke="#f6c278" stroke-width="3.5" stroke-linecap="round"/>' +
                '<line x1="92" y1="56" x2="86" y2="62" stroke="#f6c278" stroke-width="3.5" stroke-linecap="round"/>' +
                '<text x="135" y="136" fill="#c69550" font-size="8.5" font-weight="700" font-family="sans-serif" text-anchor="end" letter-spacing="1">LANE</text>' +
                '</svg>';
        }
    }

    function getGrungeLaneSvg() {
        return '<svg width="100%" height="100%" viewBox="0 0 145 145" xmlns="http://www.w3.org/2000/svg">' +
            '<rect width="145" height="145" fill="#0d0d0d"/>' +
            '<text x="72" y="85" fill="#666666" font-size="28" font-weight="900" font-family="monospace" text-anchor="middle" letter-spacing="4">LANE</text>' +
            '</svg>';
    }

    function playDailyMix(mixType, mixTitle) {
        var baseTracks = (cachedHomeTracks && cachedHomeTracks.length > 0) ? cachedHomeTracks : cachedLibraryTracks;
        if (!baseTracks || baseTracks.length === 0) {
            Player.showNotification('Загрузка ' + mixTitle + '...');
            LaneApi.getHomeFeed().then(function(res) {
                if (res && res.sections && res.sections.length > 0) {
                    for (var s = 0; s < res.sections.length; s++) {
                        var sec = res.sections[s];
                        if (sec.content && sec.content.length > 0) {
                            for (var c = 0; c < sec.content.length; c++) {
                                if (sec.content[c].playlist && sec.content[c].playlist.playlistId) {
                                    return LaneApi.getPlaylistTracks(sec.content[c].playlist.playlistId).then(function(pRes) {
                                        var tr = extractTracks(pRes);
                                        if (tr.length > 0) {
                                            cachedHomeTracks = tr;
                                            Player.playTrack(tr[0], tr, 0);
                                            Player.showNotification('Включен: ' + mixTitle);
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }).catch(function() {
                Player.showNotification('Не удалось загрузить микс');
            });
            return;
        }

        var list = baseTracks.slice();
        for (var i = list.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }

        Player.playTrack(list[0], list, 0);
        Player.showNotification('Включен: ' + mixTitle);
    }

    function renderMixesAndSections() {
        var userName = getUserDisplayName();
        var hour = new Date().getHours();
        var currentType = 'day';
        var currentTitle = 'Добрый день Mix';
        if (hour >= 5 && hour < 12) {
            currentType = 'morning';
            currentTitle = 'Доброе утро Mix';
        } else if (hour >= 12 && hour < 18) {
            currentType = 'day';
            currentTitle = 'Добрый день Mix';
        } else if (hour >= 18 && hour < 23) {
            currentType = 'evening';
            currentTitle = 'Добрый вечер Mix';
        } else {
            currentType = 'night';
            currentTitle = 'Доброй ночи Mix';
        }

        // 1. Featured Top Card
        var featArt = document.getElementById('featuredMixArt');
        var featTitle = document.getElementById('featuredMixTitle');
        var featSub = document.getElementById('featuredMixSub');
        var featCard = document.getElementById('featuredMixCard');

        if (featArt) featArt.innerHTML = getMixArtworkSvg(currentType);
        if (featTitle) featTitle.textContent = currentTitle;
        if (featSub) featSub.textContent = 'Подобрано специально для ' + userName;
        if (featCard) {
            featCard.onclick = function() {
                playDailyMix(currentType, currentTitle);
            };
        }

        // 2. Horizontal Carousel (Недавно прослушано / Другие подборки)
        var carousel = document.getElementById('recentMixesScroll');
        if (!carousel) return;

        var carouselItems = [];

        // Add user playlists first if available (like "xP")
        if (cachedPlaylists && cachedPlaylists.length > 0) {
            for (var p = 0; p < Math.min(cachedPlaylists.length, 4); p++) {
                var pl = cachedPlaylists[p];
                carouselItems.push({
                    kind: 'playlist',
                    id: pl.playlistId || pl.id,
                    title: pl.playlistName || pl.name || pl.title || 'Плейлист',
                    subtitle: pl.ownerName || pl.author || userName,
                    coverUrl: pl.playlistImageUrl || pl.coverUrl || pl.image || ''
                });
            }
        }

        // Add the other daily mixes
        var allMixes = [
            { type: 'evening', title: 'Добрый вечер Mix' },
            { type: 'night', title: 'Доброй ночи Mix' },
            { type: 'day', title: 'Добрый день Mix' },
            { type: 'morning', title: 'Доброе утро Mix' }
        ];

        for (var m = 0; m < allMixes.length; m++) {
            if (allMixes[m].type !== currentType) {
                carouselItems.push({
                    kind: 'mix',
                    type: allMixes[m].type,
                    title: allMixes[m].title,
                    subtitle: 'Подобрано специально для ' + userName
                });
            }
        }

        carousel.innerHTML = '';
        for (var c = 0; c < carouselItems.length; c++) {
            (function(item) {
                var card = document.createElement('div');
                card.className = 'mix-carousel-card';

                var artHtml = '';
                if (item.kind === 'mix') {
                    artHtml = getMixArtworkSvg(item.type);
                } else if (item.coverUrl) {
                    artHtml = '<img src="' + normalizeCoverUrl(item.coverUrl) + '" alt="" decoding="async" onerror="this.onerror=null; this.parentNode.innerHTML=getGrungeLaneSvg();">';
                } else {
                    artHtml = getGrungeLaneSvg();
                }

                card.innerHTML = 
                    '<div class="mix-carousel-art">' + artHtml + '</div>' +
                    '<div class="mix-carousel-title">' + escapeHtml(item.title) + '</div>' +
                    '<div class="mix-carousel-sub">' + escapeHtml(item.subtitle) + '</div>';

                card.addEventListener('click', function() {
                    if (item.kind === 'mix') {
                        playDailyMix(item.type, item.title);
                    } else if (item.id) {
                        Player.showNotification('Загрузка ' + item.title + '...');
                        LaneApi.getPlaylistTracks(item.id).then(function(res) {
                            var tr = extractTracks(res);
                            if (tr.length > 0) {
                                Player.playTrack(tr[0], tr, 0);
                                Player.showNotification('Играет: ' + item.title);
                            } else {
                                Player.showNotification('Плейлист пуст');
                            }
                        }).catch(function() {
                            Player.showNotification('Ошибка загрузки');
                        });
                    }
                });

                carousel.appendChild(card);
            })(carouselItems[c]);
        }
    }

    function initMixesUI() {
        var tabTracks = document.getElementById('tabLibraryTracks');
        var tabPlaylists = document.getElementById('tabLibraryPlaylists');

        if (tabTracks) {
            tabTracks.addEventListener('click', function() {
                var el = document.getElementById('librarySubheading');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
            });
        }

        if (tabPlaylists) {
            tabPlaylists.addEventListener('click', function() {
                try {
                    switchToTab(2); // Switches directly to 'page-playlists'
                } catch(e) {
                    console.error('tabPlaylists error:', e);
                }
            });
        }

        renderMixesAndSections();
    }

    // 9. Library (Моя музыка - Instant Display + Background Sync)
    function loadLibrary(forceRefresh) {
        updateGreeting();
        renderMixesAndSections();
        var container = document.getElementById('libraryTracksList');
        if (!container) return;

        if (!LaneApi.isAuthorized()) {
            container.innerHTML = 
                '<div class="metro-empty-state" style="padding:40px 16px;">' +
                    '<div style="font-size:16px; font-weight:600; color:#fff; margin-bottom:8px;">Вход в аккаунт LANE</div>' +
                    '<div style="color:#888; font-size:12px; margin-bottom:16px; line-height:1.5;">Для доступа к вашей медиатеке и любимым трекам вставьте токен в настройках.</div>' +
                    '<button id="libOpenGuideBtn" class="metro-button" style="padding:10px 20px;">Как войти? (Инструкция)</button>' +
                '</div>';
            var gBtn = document.getElementById('libOpenGuideBtn');
            if (gBtn) {
                gBtn.addEventListener('click', function() {
                    var m = document.getElementById('loginGuideModalBackdrop');
                    if (m) {
                        m.classList.add('active');
                        m.classList.add('visible');
                    }
                });
            }
            return;
        }

        // 1. If already rendered or in-memory, show immediately!
        if (cachedLibraryTracks && !forceRefresh) {
            renderTrackList(container, cachedLibraryTracks);
        } else if (!cachedLibraryTracks) {
            container.innerHTML = '<div class="metro-empty-state">загрузка медиатеки...</div>';
        }

        // 2. Fetch fresh from server and persist
        LaneApi.getPlaylistTracks('lane_likes').then(function(res) {
            var tracks = extractTracks(res);
            if (tracks.length > 0) {
                cachedLibraryTracks = tracks;
                try { localStorage.setItem('lane_library_cache', JSON.stringify(tracks)); } catch(e) {}
                renderTrackList(container, tracks);
            } else if (!cachedLibraryTracks) {
                container.innerHTML = '<div class="metro-empty-state">в медиатеке пока нет треков</div>';
            }
        }).catch(function(err) {
            if (!cachedLibraryTracks) {
                container.innerHTML = '<div style="text-align:center; padding: 40px 10px; color:#ef4444; font-size:13px;">' + (err.message || 'Ошибка загрузки треков') + '</div>';
            }
        });
    }

    // 10. Playlists UI
    function initPlaylistsUI() {
        var backBtn = document.getElementById('closePlaylistViewBtn');
        if (backBtn) {
            backBtn.addEventListener('click', function() {
                document.getElementById('playlistTracksSection').style.display = 'none';
                document.getElementById('playlistsContainer').style.display = 'grid';
            });
        }
    }

    function loadPlaylists(forceRefresh) {
        var container = document.getElementById('playlistsContainer');
        if (!container) return;

        if (cachedPlaylists && !forceRefresh) {
            renderPlaylists(container, cachedPlaylists);
            return;
        }

        container.innerHTML = '<div class="metro-empty-state" style="grid-column: span 2;">загрузка плейлистов...</div>';

        LaneApi.getUserPlaylists().then(function(res) {
            var list = Array.isArray(res) ? res : (res.items || res.playlists || []);
            cachedPlaylists = list;
            renderPlaylists(container, list);
            if (typeof renderMixesAndSections === 'function') {
                renderMixesAndSections();
            }
        }).catch(function(err) {
            console.error('Playlists error:', err);
            container.innerHTML = '<div style="grid-column: span 2; text-align:center; padding:40px 10px; color:#ef4444; font-size:13px;">Ошибка загрузки плейлистов</div>';
        });
    }

    function renderPlaylists(container, playlists) {
        container.innerHTML = '';
        if (!playlists || playlists.length === 0) {
            container.innerHTML = '<div class="metro-empty-state" style="grid-column: span 2;">плейлисты не найдены</div>';
            return;
        }

        for (var i = 0; i < playlists.length; i++) {
            (function(pl) {
                var card = document.createElement('div');
                card.className = 'metro-playlist-card';
                var name = pl.playlistName || pl.name || pl.title || 'Плейлист';
                var id = pl.playlistId || pl.id || '';
                var cover = normalizeCoverUrl(pl.playlistImageUrl || pl.coverUrl || pl.image || '');

                card.innerHTML = 
                    '<img class="metro-playlist-cover" src="' + cover + '" decoding="async" alt="" onerror="this.onerror=null; this.src=\'assets/default_cover.png\';">' +
                    '<div class="metro-playlist-title">' + escapeHtml(name) + '</div>' +
                    '<div class="metro-playlist-count">LANE Плейлист</div>';

                attachMetroTilt(card);

                card.addEventListener('click', function() {
                    openPlaylistTracks(id, name);
                });

                container.appendChild(card);
            })(playlists[i]);
        }
    }

    function openPlaylistTracks(playlistId, playlistTitle) {
        var grid = document.getElementById('playlistsContainer');
        var section = document.getElementById('playlistTracksSection');
        var titleEl = document.getElementById('playlistActiveTitle');
        var listEl = document.getElementById('playlistTracksList');

        if (grid) grid.style.display = 'none';
        if (section) section.style.display = 'block';
        if (titleEl) titleEl.innerText = playlistTitle;
        if (listEl) listEl.innerHTML = '<div class="metro-empty-state">загрузка треков плейлиста...</div>';

        LaneApi.getPlaylistTracks(playlistId).then(function(res) {
            var tracks = extractTracks(res);
            if (tracks.length === 0) {
                listEl.innerHTML = '<div class="metro-empty-state">в плейлисте нет треков</div>';
                return;
            }
            renderTrackList(listEl, tracks);
        }).catch(function(err) {
            listEl.innerHTML = '<div style="text-align:center; padding:30px 10px; color:#ef4444; font-size:13px;">Ошибка загрузки треков</div>';
        });
    }

    // 11. Extract tracks helper
    function extractTracks(res) {
        if (!res) return [];
        if (Array.isArray(res)) {
            var out = [];
            for (var i = 0; i < res.length; i++) out.push(normalizeTrack(res[i]));
            return out;
        }
        if (res.results && Array.isArray(res.results)) {
            var out = [];
            for (var r = 0; r < res.results.length; r++) {
                var it = res.results[r];
                if (it.track) {
                    var tr = it.track;
                    if (!tr.platform && it.platform) tr.platform = it.platform;
                    out.push(normalizeTrack(tr));
                } else if (it.type === 'track') {
                    out.push(normalizeTrack(it));
                }
            }
            return out;
        }
        if (res.items && Array.isArray(res.items)) {
            var out = [];
            for (var i = 0; i < res.items.length; i++) out.push(normalizeTrack(res.items[i]));
            return out;
        }
        if (res.tracks && Array.isArray(res.tracks)) {
            var out = [];
            for (var i = 0; i < res.tracks.length; i++) out.push(normalizeTrack(res.tracks[i]));
            return out;
        }
        if (res.data && Array.isArray(res.data)) {
            var out = [];
            for (var i = 0; i < res.data.length; i++) out.push(normalizeTrack(res.data[i]));
            return out;
        }
        if (res.sections && Array.isArray(res.sections)) {
            var all = [];
            for (var s = 0; s < res.sections.length; s++) {
                var sec = res.sections[s];
                if (sec.content && Array.isArray(sec.content)) {
                    for (var c = 0; c < sec.content.length; c++) {
                        var it = sec.content[c];
                        if (it.track) all.push(normalizeTrack(it.track));
                        if (it.playlist && it.playlist.tracks && Array.isArray(it.playlist.tracks)) {
                            for (var p = 0; p < it.playlist.tracks.length; p++) {
                                all.push(normalizeTrack(it.playlist.tracks[p]));
                            }
                        }
                    }
                }
            }
            return all;
        }
        return [];
    }

    // Official Russian CDN mirror
    function normalizeCoverUrl(url) {
        if (!url) return 'assets/default_cover.png';
        
        if (url.indexOf('https://ru.laneapi.com/cdn/') === 0) return url;

        var scMatch = url.match(/i\.scdn\.co\/image\/([a-zA-Z0-9]+)/);
        if (scMatch && scMatch[1]) {
            return 'https://ru.laneapi.com/cdn/spotify/i.scdn.co/image/' + scMatch[1];
        }

        var sndMatch = url.match(/(artworks-[a-zA-Z0-9_-]+-t[0-9]+x[0-9]+\.(jpg|png|jpeg))/);
        if (sndMatch && sndMatch[1]) {
            return 'https://ru.laneapi.com/cdn/soundcloud/' + sndMatch[1];
        }

        if (url.indexOf('https://cdn.laneapi.com/') === 0) {
            return url.replace('https://cdn.laneapi.com/', 'https://ru.laneapi.com/cdn/');
        }

        if (url.indexOf('https://laneapi.com/cdn/') === 0) {
            return url.replace('https://laneapi.com/cdn/', 'https://ru.laneapi.com/cdn/');
        }

        return url;
    }

    function normalizeTrack(t) {
        if (!t) return { id: '', title: 'Без названия', artist: 'LANE', coverUrl: 'assets/default_cover.png', duration: 0, platform: '' };
        var id = t.songId || t.trackId || t.id || '';
        var title = t.title || t.name || 'Без названия';
        var artist = t.artistsDisplayedName || t.artist || t.subtitle || (t.artists && t.artists[0] && (t.artists[0].name || t.artists[0])) || 'LANE';
        var rawCover = t.coverUrl || t.cover || t.image || (t.images && t.images[0] && (t.images[0].url || t.images[0])) || '';
        var coverUrl = normalizeCoverUrl(rawCover);
        var platform = (t.platform || t.source || '').toLowerCase();
        if (!platform) {
            if (id.indexOf('spotify:') === 0 || id.indexOf('sp:') === 0) platform = 'spotify';
            else if (id.indexOf('soundcloud:') === 0 || id.indexOf('sc:') === 0) platform = 'soundcloud';
        }

        return {
            id: id,
            title: title,
            artist: artist,
            coverUrl: coverUrl,
            duration: t.duration || 0,
            platform: platform
        };
    }

    // 12. Render Track List with DocumentFragment & 3D Tilt
    function renderTrackList(container, tracks) {
        container.innerHTML = '';
        if (!tracks || tracks.length === 0) {
            container.innerHTML = '<div class="metro-empty-state">треки не найдены</div>';
            return;
        }

        var fragment = document.createDocumentFragment();

        for (var i = 0; i < tracks.length; i++) {
            (function(track, idx) {
                var el = document.createElement('div');
                el.className = 'metro-track-item';
                el.setAttribute('data-id', track.id);
                if (Player.currentTrack && Player.currentTrack.id === track.id) {
                    el.classList.add('playing');
                }

                var durStr = '';
                if (track.duration && track.duration > 0) {
                    var m = Math.floor(track.duration / 60);
                    var s = Math.floor(track.duration % 60);
                    durStr = m + ':' + (s < 10 ? '0' : '') + s;
                }

                var platBadge = '';
                var plat = (track.platform || '').toLowerCase();
                if (plat.indexOf('spotify') !== -1) {
                    platBadge = '<img src="assets/spotify_logo.png" class="metro-platform-badge" alt="Spotify"> ';
                } else if (plat.indexOf('soundcloud') !== -1 || plat === 'sc') {
                    platBadge = '<img src="assets/soundcloud_logo.png" class="metro-platform-badge" alt="SoundCloud"> ';
                }

                el.innerHTML = 
                    '<img class="metro-cover" src="' + track.coverUrl + '" decoding="async" alt="" onerror="this.onerror=null; this.src=\'assets/default_cover.png\';">' +
                    '<div class="metro-meta">' +
                        '<div class="metro-track-title">' + escapeHtml(track.title) + '</div>' +
                        '<div class="metro-track-artist">' + platBadge + escapeHtml(track.artist) + '</div>' +
                    '</div>' +
                    '<div class="metro-track-right">' +
                        '<span class="metro-duration">' + durStr + '</span>' +
                        '<span class="mdl2 metro-play-glyph">&#xE768;</span>' +
                    '</div>';

                attachMetroTilt(el);

                el.addEventListener('click', function() {
                    var all = document.querySelectorAll('.metro-track-item');
                    for (var k = 0; k < all.length; k++) all[k].classList.remove('playing');
                    el.classList.add('playing');
                    Player.playTrack(track, tracks, idx);
                });

                fragment.appendChild(el);
            })(tracks[i], i);
        }

        container.appendChild(fragment);
    }

    // Windows Phone 8.1 / 10 Mobile 3D Perspective Tilt on Touch
    function attachMetroTilt(el) {
        var rect = null;
        var isTouching = false;

        el.addEventListener('touchstart', function(e) {
            if (!e.touches || e.touches.length === 0) return;
            rect = el.getBoundingClientRect();
            isTouching = true;
            el.classList.add('tilting');
            applyTilt(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });

        el.addEventListener('touchmove', function(e) {
            if (!isTouching || !rect || !e.touches || e.touches.length === 0) return;
            applyTilt(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });

        function resetTilt() {
            if (!isTouching) return;
            isTouching = false;
            rect = null;
            el.classList.remove('tilting');
            el.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
        }

        el.addEventListener('touchend', resetTilt, { passive: true });
        el.addEventListener('touchcancel', resetTilt, { passive: true });

        function applyTilt(clientX, clientY) {
            if (!rect) return;
            var relX = clientX - rect.left;
            var relY = clientY - rect.top;
            var centerX = rect.width / 2;
            var centerY = rect.height / 2;

            var normX = Math.max(-1, Math.min(1, (relX - centerX) / centerX));
            var normY = Math.max(-1, Math.min(1, (relY - centerY) / centerY));

            var rotX = (-normY * 16).toFixed(1);
            var rotY = (normX * 12).toFixed(1);

            el.style.transform = 'perspective(800px) rotateX(' + rotX + 'deg) rotateY(' + rotY + 'deg) scale3d(0.96, 0.96, 0.96)';
        }
    }

    function renderFallbackTracks(container) {
        container.innerHTML = 
            '<div class="settings-block" style="margin-top:10px;">' +
                '<div class="settings-label">РЕЖИМ ГОСТЯ</div>' +
                '<div class="settings-subtext">Для доступа к медиатеке и персональным миксам перейдите на вкладку «Аккаунт» и выполните быстрый вход.</div>' +
            '</div>';
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    // 13. Groove Music Player UI & Modals
    function initPlayerModals() {
        var miniMeta = document.getElementById('miniMetaClick');
        var miniCover = document.getElementById('miniCover');
        var fullModal = document.getElementById('fullPlayerModal');
        var fullClose = document.getElementById('fullCloseBtn');

        function openFullPlayer() {
            if (fullModal) fullModal.classList.add('active');
        }

        if (miniMeta) miniMeta.addEventListener('click', openFullPlayer);
        if (miniCover) miniCover.addEventListener('click', openFullPlayer);
        if (fullClose) {
            fullClose.addEventListener('click', function() {
                if (fullModal) fullModal.classList.remove('active');
            });
        }

        var miniPlay = document.getElementById('miniPlayBtn');
        if (miniPlay) {
            miniPlay.addEventListener('click', function(e) {
                e.stopPropagation();
                Player.togglePlay();
            });
        }

        var miniNext = document.getElementById('miniNextBtn');
        if (miniNext) {
            miniNext.addEventListener('click', function(e) {
                e.stopPropagation();
                Player.next();
            });
        }

        var fullPlay = document.getElementById('fullPlayBtn');
        if (fullPlay) fullPlay.addEventListener('click', function() { Player.togglePlay(); });

        var fullNext = document.getElementById('fullNextBtn');
        if (fullNext) fullNext.addEventListener('click', function() { Player.next(); });

        var fullPrev = document.getElementById('fullPrevBtn');
        if (fullPrev) fullPrev.addEventListener('click', function() { Player.prev(); });

        var progressTrack = document.getElementById('progressTrack');
        if (progressTrack) {
            progressTrack.addEventListener('click', function(e) {
                var rect = progressTrack.getBoundingClientRect();
                var x = e.clientX - rect.left;
                var pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
                Player.seek(pct);
            });
        }

        // 14. Fullscreen Action Buttons: Repeat, Like, Comments
        var repeatBtn = document.getElementById('fullRepeatBtn');
        if (repeatBtn) {
            repeatBtn.addEventListener('click', function() {
                Player.toggleRepeat();
            });
        }

        // Like Button Logic
        var likeBtn = document.getElementById('fullLikeBtn');
        var likeIcon = document.getElementById('fullLikeIcon');

        function isCurrentTrackLiked() {
            var track = Player.currentTrack;
            if (!track || !cachedLibraryTracks) return false;
            for (var i = 0; i < cachedLibraryTracks.length; i++) {
                if (cachedLibraryTracks[i].id === track.id) return true;
            }
            return false;
        }

        function updateLikeUI() {
            if (!likeBtn || !likeIcon) return;
            var liked = isCurrentTrackLiked();
            if (liked) {
                likeIcon.innerHTML = '&#xEB52;'; // Filled heart
                likeBtn.style.color = '#e51c23';
                likeBtn.style.opacity = '1';
                likeBtn.classList.add('active');
            } else {
                likeIcon.innerHTML = '&#xEB51;'; // Outline heart
                likeBtn.style.color = '#ffffff';
                likeBtn.style.opacity = '0.7';
                likeBtn.classList.remove('active');
            }
        }

        window.onPlayerTrackChanged = function(track) {
            updateLikeUI();
            var subhead = document.getElementById('commentsTrackSubhead');
            if (subhead && track) {
                subhead.innerText = (track.title || '') + ' — ' + (track.artist || '');
            }
        };

        if (likeBtn) {
            likeBtn.addEventListener('click', function() {
                var track = Player.currentTrack;
                if (!track || !track.id) return;
                if (!LaneApi.isAuthorized()) {
                    Player.showNotification('Для добавления в медиатеку войдите в аккаунт');
                    return;
                }

                var wasLiked = isCurrentTrackLiked();
                if (!wasLiked) {
                    LaneApi.likeTrack(track.id).then(function() {
                        Player.showNotification('Добавлено в Мою музыку!');
                        if (!cachedLibraryTracks) cachedLibraryTracks = [];
                        cachedLibraryTracks.unshift(track);
                        var libContainer = document.getElementById('libraryTracksList');
                        if (libContainer) renderTrackList(libContainer, cachedLibraryTracks);
                        updateLikeUI();
                    }).catch(function(err) {
                        Player.showNotification('Ошибка добавления трека');
                    });
                } else {
                    Player.showNotification('Трек уже в вашей медиатеке');
                }
            });
        }

        // Comments Dialog Logic
        var commentsBtn = document.getElementById('fullCommentsBtn');
        var commentsModal = document.getElementById('commentsModalBackdrop');
        var closeCommentsBtn = document.getElementById('closeCommentsBtn');
        var commentsList = document.getElementById('trackCommentsList');
        var sendCommentBtn = document.getElementById('sendCommentBtn');
        var newCommentInput = document.getElementById('newCommentInput');
        var commentsTrackSubhead = document.getElementById('commentsTrackSubhead');

        function openComments() {
            if (!commentsModal) return;
            commentsModal.classList.add('active');
            commentsModal.classList.add('visible');

            var track = Player.currentTrack;
            if (commentsTrackSubhead && track) {
                commentsTrackSubhead.innerText = (track.title || '') + ' — ' + (track.artist || '');
            }
            loadCommentsForCurrentTrack();
        }

        function closeComments() {
            if (commentsModal) {
                commentsModal.classList.remove('active');
                commentsModal.classList.remove('visible');
            }
        }

        if (commentsBtn) commentsBtn.addEventListener('click', openComments);
        if (closeCommentsBtn) closeCommentsBtn.addEventListener('click', closeComments);
        if (commentsModal) {
            commentsModal.addEventListener('click', function(e) {
                if (e.target === commentsModal) closeComments();
            });
        }

        function loadCommentsForCurrentTrack() {
            var track = Player.currentTrack;
            if (!track || !track.id) {
                if (commentsList) commentsList.innerHTML = '<div class="metro-empty-state">нет выбранного трека</div>';
                return;
            }
            if (commentsList) commentsList.innerHTML = '<div class="metro-empty-state">загрузка комментариев...</div>';

            LaneApi.getTrackComments(track.id).then(function(res) {
                var items = [];
                if (Array.isArray(res)) items = res;
                else if (res && Array.isArray(res.items)) items = res.items;
                else if (res && Array.isArray(res.data)) items = res.data;
                else if (res && Array.isArray(res.comments)) items = res.comments;

                renderComments(items);
            }).catch(function() {
                if (commentsList) commentsList.innerHTML = '<div class="metro-empty-state">комментарии пока отсутствуют или временно недоступны</div>';
            });
        }

        function renderComments(items) {
            if (!commentsList) return;
            commentsList.innerHTML = '';
            if (!items || items.length === 0) {
                commentsList.innerHTML = '<div class="metro-empty-state">пока нет комментариев. Напишите первый!</div>';
                return;
            }

            var frag = document.createDocumentFragment();
            for (var i = 0; i < items.length; i++) {
                var c = items[i];
                var author = c.authorName || c.userName || (c.user && (c.user.name || c.user.userName)) || (c.author && c.author.name) || 'Пользователь';
                var text = c.text || c.content || c.body || '';
                var dateStr = '';
                if (c.createdAt || c.timestamp) {
                    try {
                        var d = new Date(c.createdAt || c.timestamp);
                        dateStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    } catch(ex) {}
                }
                var likes = c.likesCount || c.likes || 0;

                var card = document.createElement('div');
                card.className = 'comment-card';
                card.innerHTML = 
                    '<div class="comment-author-row">' +
                        '<span class="comment-author-name">' + escapeHtml(author) + '</span>' +
                        '<span class="comment-time">' + escapeHtml(dateStr) + '</span>' +
                    '</div>' +
                    '<div class="comment-body">' + escapeHtml(text) + '</div>' +
                    (likes > 0 ? ('<div class="comment-likes-row"><span class="mdl2" style="font-size:10px; color:#e51c23;">&#xEB52;</span> ' + likes + '</div>') : '');
                frag.appendChild(card);
            }
            commentsList.appendChild(frag);
        }

        if (sendCommentBtn && newCommentInput) {
            sendCommentBtn.addEventListener('click', function() {
                var text = newCommentInput.value.trim();
                if (!text) return;
                var track = Player.currentTrack;
                if (!track || !track.id) return;
                if (!LaneApi.isAuthorized()) {
                    Player.showNotification('Для отправки комментариев войдите в аккаунт');
                    return;
                }
                Player.showNotification('Отправка комментария...');
                newCommentInput.value = '';
                LaneApi.postTrackComment(track.id, text).then(function() {
                    Player.showNotification('Комментарий опубликован!');
                    loadCommentsForCurrentTrack();
                }).catch(function(err) {
                    Player.showNotification('Ошибка отправки (' + ((err && err.message) || 'ошибка') + ')');
                });
            });
        }
    }

    function isUuid(str) {
        if (!str || typeof str !== 'string') return false;
        return /^[0-9a-f]{8}-[0-9a-f]{4}/i.test(str) || /^[0-9a-f]{10,}$/i.test(str);
    }

    // 15. Dynamic Time-of-Day Greeting in "Моя музыка"
    function updateGreeting() {
        var greetingEl = document.getElementById('libraryGreetingText');
        if (!greetingEl) return;

        var hour = new Date().getHours();
        var greeting = 'Добрый день';
        if (hour >= 5 && hour < 12) {
            greeting = 'Доброе утро';
        } else if (hour >= 12 && hour < 18) {
            greeting = 'Добрый день';
        } else if (hour >= 18 && hour < 23) {
            greeting = 'Добрый вечер';
        } else {
            greeting = 'Доброй ночи';
        }

        var userName = '';

        // 1. Custom user-defined nickname
        try {
            var custom = localStorage.getItem('lane_custom_nickname');
            if (custom && custom.trim() && !isUuid(custom)) {
                userName = custom.trim();
            }
        } catch(e) {}

        // 2. Cached profile from /user-info
        if (!userName) {
            try {
                var cachedProfile = JSON.parse(localStorage.getItem('lane_user_profile') || '{}');
                var cName = cachedProfile.displayedName || cachedProfile.userName || cachedProfile.username || cachedProfile.name || '';
                if (cName && !isUuid(cName)) {
                    userName = cName;
                }
            } catch(e) {}
        }

        // 3. SplitView user name if human-readable
        if (!userName) {
            var splitName = document.getElementById('splitViewUserName');
            if (splitName && splitName.innerText) {
                var sTxt = splitName.innerText.trim();
                if (sTxt !== 'Гость' && sTxt !== 'Не авторизован' && sTxt !== 'LANE User' && !isUuid(sTxt)) {
                    userName = sTxt;
                }
            }
        }

        // 4. JWT token claims (excluding raw laneId UUID)
        if (!userName) {
            var payload = LaneApi.decodeToken();
            if (payload) {
                var candidate = payload.displayedName || payload.userName || payload.username || payload.name || '';
                if (candidate && !isUuid(candidate)) {
                    userName = candidate;
                }
            }
        }

        if (userName) {
            greetingEl.innerText = greeting + ', ' + userName + '!';
        } else {
            greetingEl.innerText = greeting + '!';
        }
    }

    // 16. In-App OTA Updater (proshivka.github.io/lane/update.json)
    var APP_VERSION = '1.3.9.0';
    var APP_VERSION_CODE = 1030900;
    var OTA_MANIFEST_URL = 'https://proshivka.github.io/lane/update.json';

    function initOtaUpdater() {
        var checkBtn = document.getElementById('otaCheckBtn');
        var modal = document.getElementById('otaModalBackdrop');
        var dismissBtn = document.getElementById('otaDismissBtn');
        var dismissCloseBtn = document.getElementById('otaDismissCloseBtn');
        var installBtn = document.getElementById('otaInstallBtn');
        var titleEl = document.getElementById('otaNewVersionTitle');
        var dateEl = document.getElementById('otaReleaseDate');
        var changelogEl = document.getElementById('otaChangelogText');
        var statusEl = document.getElementById('otaStatusText');
        var progressBox = document.getElementById('otaProgressBox');
        var progressPct = document.getElementById('otaProgressPct');
        var progressBar = document.getElementById('otaProgressBar');
        var progressStatus = document.getElementById('otaProgressStatus');
        var buttonsRow = document.getElementById('otaButtonsRow');

        if (checkBtn) {
            checkBtn.addEventListener('click', function() {
                checkOta(true);
            });
        }

        if (dismissBtn && modal) {
            dismissBtn.addEventListener('click', function() {
                modal.classList.remove('active');
            });
        }
        if (dismissCloseBtn && modal) {
            dismissCloseBtn.addEventListener('click', function() {
                modal.classList.remove('active');
            });
        }
        if (installBtn) {
            installBtn.addEventListener('click', function(e) {
                if (e) e.preventDefault();
                var targetUrl = (lastManifest && lastManifest.downloadUrl) ? lastManifest.downloadUrl : 'https://proshivka.github.io/lane/LaneMusic.appxbundle';
                startInAppUpdate(targetUrl);
            });
        }

        var lastManifest = null;

        function checkOta(manual) {
            if (manual && statusEl) statusEl.textContent = 'Проверка обновлений...';
            var url = OTA_MANIFEST_URL + '?_t=' + Date.now();

            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.timeout = 8000;
            xhr.onload = function() {
                try {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var res = JSON.parse(xhr.responseText);
                        lastManifest = res;
                        var remoteCode = parseInt(res.versionCode) || 0;
                        var remoteVer = res.version || '';

                        var isNewer = false;
                        if (remoteCode > 0) {
                            isNewer = (remoteCode > APP_VERSION_CODE);
                        } else if (remoteVer) {
                            isNewer = (remoteVer !== APP_VERSION);
                        }

                        if (isNewer) {
                            if (statusEl) statusEl.textContent = 'Доступна версия ' + remoteVer;
                            if (titleEl) titleEl.textContent = res.title || ('LANE Music v' + remoteVer);
                            if (dateEl) dateEl.textContent = 'Релиз: ' + (res.releaseDate || 'недавно');
                            if (changelogEl) changelogEl.textContent = res.changelog || 'Улучшения стабильности и новые функции.';

                            // Reset progress box
                            if (progressBox) progressBox.style.display = 'none';
                            if (buttonsRow) buttonsRow.style.display = 'flex';
                            if (installBtn) {
                                installBtn.disabled = false;
                                installBtn.textContent = 'Скачать и обновить';
                            }

                            if (modal) modal.classList.add('active');
                        } else {
                            if (statusEl) statusEl.textContent = 'У вас актуальная версия';
                            if (manual) {
                                Player.showNotification('У вас последняя версия (v' + APP_VERSION + ')');
                            }
                        }
                    } else if (manual) {
                        if (statusEl) statusEl.textContent = 'Ошибка сервера обновлений';
                        Player.showNotification('Не удалось проверить обновления');
                    }
                } catch(e) {
                    if (manual) {
                        if (statusEl) statusEl.textContent = 'Ошибка проверки';
                        Player.showNotification('Ошибка проверки обновлений');
                    }
                }
            };
            xhr.onerror = function() {
                if (statusEl) statusEl.textContent = 'Нет связи с сервером OTA';
                if (manual) Player.showNotification('Нет подключения к серверу обновлений');
            };
            xhr.send();
        }

        function startInAppUpdate(downloadUrl) {
            if (!downloadUrl) return;

            if (buttonsRow) buttonsRow.style.display = 'none';
            if (progressBox) progressBox.style.display = 'block';
            if (progressStatus) progressStatus.textContent = 'Скачивание обновления...';
            if (progressBar) progressBar.style.width = '0%';
            if (progressPct) progressPct.textContent = '0%';

            var xhr = new XMLHttpRequest();
            xhr.open('GET', downloadUrl, true);
            xhr.responseType = 'arraybuffer';

            xhr.onprogress = function(e) {
                if (e.lengthComputable && e.total > 0) {
                    var pct = Math.round((e.loaded / e.total) * 100);
                    if (progressBar) progressBar.style.width = pct + '%';
                    if (progressPct) progressPct.textContent = pct + '%';
                    if (progressStatus) progressStatus.textContent = 'Загрузка: ' + Math.round(e.loaded / 1024) + ' из ' + Math.round(e.total / 1024) + ' КБ';
                }
            };

            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    if (progressStatus) progressStatus.textContent = 'Установка обновления...';
                    if (progressBar) progressBar.style.width = '100%';
                    if (progressPct) progressPct.textContent = '100%';

                    saveAndLaunchPackage(xhr.response, downloadUrl);
                } else {
                    fallbackBrowser(downloadUrl, 'Ошибка загрузки (код ' + xhr.status + ')');
                }
            };

            xhr.onerror = function() {
                fallbackBrowser(downloadUrl, 'Сетевая ошибка при загрузке');
            };

            xhr.send();
        }

        function saveAndLaunchPackage(arrayBuffer, fallbackUrl) {
            try {
                if (typeof Windows !== 'undefined' && Windows.Storage) {
                    var createFilePromise = null;
                    if (Windows.Storage.DownloadsFolder && typeof Windows.Storage.DownloadsFolder.createFileAsync === 'function') {
                        createFilePromise = Windows.Storage.DownloadsFolder.createFileAsync('LaneMusic_Update.appxbundle', Windows.Storage.CreationCollisionOption.generateUniqueName);
                    } else {
                        createFilePromise = Windows.Storage.ApplicationData.current.temporaryFolder.createFileAsync('LaneMusic_OTA_Update.appxbundle', Windows.Storage.CreationCollisionOption.replaceExisting);
                    }

                    createFilePromise
                        .then(function(file) {
                            var crypt = Windows.Security.Cryptography.CryptographicBuffer;
                            var buf = crypt.createFromByteArray(new Uint8Array(arrayBuffer));
                            return Windows.Storage.FileIO.writeBufferAsync(file, buf).then(function() {
                                return file;
                            });
                        })
                        .then(function(file) {
                            if (progressStatus) progressStatus.textContent = 'Запуск установщика Windows...';
                            var launchOptions = new Windows.System.LauncherOptions();
                            launchOptions.displayApplicationPicker = false;
                            return Windows.System.Launcher.launchFileAsync(file, launchOptions);
                        })
                        .then(function() {
                            if (modal) modal.classList.remove('active');
                            if (buttonsRow) buttonsRow.style.display = 'flex';
                            if (progressBox) progressBox.style.display = 'none';
                        })
                        .catch(function(err) {
                            console.warn('File launch failed, falling back to URL:', err);
                            fallbackBrowser(fallbackUrl);
                        });
                } else {
                    fallbackBrowser(fallbackUrl);
                }
            } catch(e) {
                fallbackBrowser(fallbackUrl);
            }
        }

        function fallbackBrowser(targetUrl, errMsg) {
            if (errMsg) Player.showNotification(errMsg);
            try {
                if (typeof Windows !== 'undefined' && Windows.System && Windows.System.Launcher) {
                    Windows.System.Launcher.launchUriAsync(new Windows.Foundation.Uri(targetUrl));
                } else {
                    window.open(targetUrl, '_blank');
                }
            } catch(e) {
                window.open(targetUrl, '_blank');
            }
            if (modal) modal.classList.remove('active');
            if (buttonsRow) buttonsRow.style.display = 'flex';
            if (progressBox) progressBox.style.display = 'none';
        }

        // Automatic quiet check 4 seconds after app launch
        setTimeout(function() {
            checkOta(false);
        }, 4000);
    }
})();
